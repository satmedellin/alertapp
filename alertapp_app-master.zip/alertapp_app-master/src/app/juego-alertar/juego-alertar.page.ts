import { Component, OnInit } from '@angular/core';
import { StorageService, Usuario } from '../services/storage.service';
import { Platform } from '@ionic/angular';
import { Router, NavigationEnd } from '@angular/router';

@Component({
  selector: 'app-juego-alertar',
  templateUrl: './juego-alertar.page.html',
  styleUrls: ['./juego-alertar.page.scss'],
})

export class JuegoAlertarPage implements OnInit {

  usuarios: Usuario[] = [];
  numUsuario: boolean;

  constructor(private storageService: StorageService, private plt: Platform, private router: Router) {
    /*this.plt.ready().then(() => {
      this.loadItems();
    });*/
    this.router.events.subscribe((ev) => {
      if (ev instanceof NavigationEnd) {
        if (ev.urlAfterRedirects === '/juego-alertar') {
          this.loadItems();
        }
      }
    });
  }

  // READ
  loadItems() {
    this.storageService.getItems().then(usuarios => {
    this.usuarios = usuarios;

    if (!this.usuarios) {
      this.numUsuario = false;
      // console.log("Es false juego-alertar");
      this.irCuenta();
    } else {
      this.numUsuario = true;
      // console.log("Es true juego-alertar");

    }

    });
  }

  irCuenta() {
    this.router.navigateByUrl('/cuenta');
  }

  ngOnInit() {
    this.loadItems();

  }

}
