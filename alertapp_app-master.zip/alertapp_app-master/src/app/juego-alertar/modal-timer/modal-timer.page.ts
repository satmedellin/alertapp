import { Component, OnInit } from '@angular/core';
import { ModalController, NavParams } from '@ionic/angular';

import { Router } from '@angular/router';

@Component({
  selector: 'app-modal-timer',
  templateUrl: './modal-timer.page.html',
  styleUrls: ['./modal-timer.page.scss'],
})
export class ModalTimerPage implements OnInit {

  tema:string;
 
  constructor(
    private modalController: ModalController,
    private navParams: NavParams,
    private router: Router
  ) { }
 

 
  async closeModal(respuesta) {

    if(respuesta == 'Si'){
      this.router.navigateByUrl('/juego-alertar');
      await this.modalController.dismiss();
      await this.modalController.dismiss();
    }else if(respuesta == 'No'){
      this.router.navigateByUrl('/satmed');
      await this.modalController.dismiss();
      await this.modalController.dismiss();
    }

    
  }

  ngOnInit() {
    this.tema = this.navParams.data.tema;
  }
}
