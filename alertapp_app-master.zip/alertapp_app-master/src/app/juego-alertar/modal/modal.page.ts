import { Pregunta } from '../../services/storage.service';
import { Component, OnInit } from '@angular/core';
import { ModalController, NavParams } from '@ionic/angular';

@Component({
  selector: 'app-modal',
  templateUrl: './modal.page.html',
  styleUrls: ['./modal.page.scss'],
})

export class ModalPage implements OnInit {

  tema: string;
  pregunta: Pregunta;

  constructor(
    private modalController: ModalController,
    private navParams: NavParams
  ) { }

  ngOnInit() {
    // console.table(this.navParams);
    this.tema = this.navParams.data.tema;
    this.pregunta = this.navParams.data.pregunta;
  }

  // guardarArray(pregunta){
  //   this.preguntasArr.push(pregunta);
  //     // this.data.splice(this.rd, 1);
  //     // console.log(this.randomPreg);
  //     // console.log('Esta es la data: ',this.data);
  // }

  async closeModal(respuesta) {
    if (respuesta === this.pregunta.resCorrecta) {
      this.pregunta.orientacion = null;
      switch(this.pregunta.resRiesgo) {
        case 'Bajo':
          this.pregunta.puntaje = 20;
          break;
        case 'Medio':
          this.pregunta.puntaje = 30;
          break;
        case 'Alto':
          this.pregunta.puntaje = 40;
          break;
      }
    } else {
      this.pregunta.puntaje = 10;
    }

    // console.log('JSON preguntas: '+ JSON.stringify(this.preguntasArr))
    await this.modalController.dismiss({pregunta: this.pregunta});
  }

}
