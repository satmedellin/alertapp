import { Component, OnInit } from '@angular/core';
import { StorageService, Usuario, Puntaje } from '../../services/storage.service';
import { Platform } from '@ionic/angular';

import { Router, ActivatedRoute } from '@angular/router';



@Component({
  selector: 'app-modal-puntaje',
  templateUrl: './modal-puntaje.page.html',
  styleUrls: ['./modal-puntaje.page.scss'],
})
export class ModalPuntajePage implements OnInit {

  imgRiesgo: string;
  puntuacion: number;
  tema: string;
  usuarios: Usuario[] = [];
  numUsuario: boolean;
  usuario: any;
  datauser: any;
  nombreUsr: string;
  riesgo: string;
  displayTime: string;
  preguntasArr = [];

  constructor(
      private router: Router,
      private route: ActivatedRoute,
      private storageService: StorageService,
      private plt: Platform
    ) {
      this.plt.ready().then(() => {
        this.loadItems();
      });
  }

  closeModal() {
      this.router.navigateByUrl('/home');
  }

  // READ
  loadItems() {
    this.storageService.getItems().then(usuarios => {
      this.usuarios = usuarios;
      this.usuario = JSON.stringify(usuarios);
      this.datauser = JSON.parse(this.usuario);
      this.nombreUsr = this.datauser[0].nombre;
      // console.log(this.datauser[0].nombre);
      if (!this.usuarios) {
        this.numUsuario = false;
        return;
    } else {
      this.numUsuario = true;
    }

    });
  }

  loadImage(riesgo: string) {
    if (riesgo === 'Alto') {
      this.imgRiesgo = '/assets/iconos-juego/alertometro_alto.png';
    } else if (riesgo === 'Medio') {
      this.imgRiesgo = '/assets/iconos-juego/alertometro_medio.png';
    } else if (riesgo === 'Bajo') {
      this.imgRiesgo = '/assets/iconos-juego/alertometro_bajo.png';
    }
  }

  ngOnInit() {
    const data = this.router.getCurrentNavigation().extras.state as Puntaje;
    this.puntuacion = data.puntuacion;
    this.tema = data.tema;
    this.riesgo = data.riesgo;
    this.preguntasArr = data.orientacion;
    this.loadImage(this.riesgo);
    // console.log('Array preguntas: ',this.preguntasArr);

    if (this.puntuacion <= 100) {
      this.riesgo = 'Alto';
    } else if (this.puntuacion >= 101 && this.puntuacion <= 199) {
      this.riesgo = 'Medio';
    } else if (this.puntuacion >= 200) {
      this.riesgo = 'Bajo';
    }

    if (this.tema === 'recl') {
      this.tema = 'Reclutamiento, Uso y Utilización de Niños, Niñas y Adolescentes';
    } else if (this.tema === 'expl') {
      this.tema = 'Explotación Sexual y Comercial de Niños, Niñas y Adolescentes - ESCNNA';
    } else if (this.tema === 'viol') {
      this.tema = 'Violencia Sexual';
    } else if (this.tema === 'trab') {
      this.tema = 'Trabajo Infantil';
    } else if (this.tema === 'emba') {
      this.tema = 'Embarazo Adolescente';
    }
    // console.log(this.imgRiesgo);
  }

  toSatmedHome() {
    this.router.navigateByUrl('/home');
    this.closeModal();
  }

}
