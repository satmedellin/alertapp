import { Component, OnInit } from '@angular/core';
import { StorageService, Usuario } from '../../services/storage.service';
import { Platform } from '@ionic/angular';

@Component({
  selector: 'app-etapa-ii',
  templateUrl: './etapa-ii.page.html',
  styleUrls: ['./etapa-ii.page.scss'],
})
export class EtapaIiPage implements OnInit {

  usuarios: Usuario[] = [];
  numUsuario: boolean;

  constructor(private storageService: StorageService, private plt: Platform) {
    this.plt.ready().then(() => {
      this.loadItems();
    });
  }

    // READ
  loadItems() {
    this.storageService.getItems().then(usuarios => {
      this.usuarios = usuarios;

      if (!this.usuarios) {
        this.numUsuario = false;
        return;
    } else {
      this.numUsuario = true;
    }

    });
  }

  ngOnInit() {
  }

}
