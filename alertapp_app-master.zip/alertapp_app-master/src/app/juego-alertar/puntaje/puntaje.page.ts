import { Component, OnInit } from '@angular/core';
import { ModalController, NavParams } from '@ionic/angular';
import { StorageService, Usuario } from '../../services/storage.service';
import { Platform } from '@ionic/angular';

import { Router } from '@angular/router';

@Component({
  selector: 'app-puntaje',
  templateUrl: './puntaje.page.html',
  styleUrls: ['./puntaje.page.scss'],
})
export class PuntajePage implements OnInit {

  imgRiesgo = this.navParams.data.imgRiesgo;

  puntuacion: number;
  tema: string;
  usuarios: Usuario[] = [];
  numUsuario: boolean;
  usuario: any;
  datauser: any;
  nombreUsr: string;
  riesgo: string;
  // imgRiesgo = this.imgRiesgo;
  displayTime: string;
  loaderToShow: any;

  constructor(
    private modalController: ModalController,
    private navParams: NavParams,
    private router: Router,
    private storageService: StorageService,
    private plt: Platform
  ) {
    this.plt.ready().then(() => {
      this.loadItems();
    });
  }

  async closeModal() {
      this.router.navigateByUrl('/home');
      await this.modalController.dismiss();
  }

  // READ
  loadItems() {
    this.storageService.getItems().then(usuarios => {
      this.usuarios = usuarios;
      this.usuario = JSON.stringify(usuarios);
      this.datauser = JSON.parse(this.usuario);
      this.nombreUsr = this.datauser[0].nombre;
      // console.log(this.datauser[0].nombre);
      if (!this.usuarios) {
        this.numUsuario = false;
        return;
    } else {
      this.numUsuario = true;
    }

    });
  }

  // async imagenRiesgo (riesgo: string) {
  //   if (riesgo === 'Alto') {
  //     this.imgRiesgo = '/assets/iconos-juego/alertometro_alto.png';
  //   } else if (riesgo === 'Medio') {
  //     this.imgRiesgo = '/assets/iconos-juego/alertometro_medio.png';
  //   } else if (riesgo === 'bajo') {
  //     this.imgRiesgo = '/assets/iconos-juego/alertometro_bajo.png';
  //   }

  //   return this.imgRiesgo;
  // }

  loadImage(riesgo: string) {
    if (riesgo === 'Alto') {
      this.imgRiesgo = '/assets/iconos-juego/alertometro_alto.png';
    } else if (riesgo === 'Medio') {
      this.imgRiesgo = '/assets/iconos-juego/alertometro_medio.png';
    } else if (riesgo === 'bajo') {
      this.imgRiesgo = '/assets/iconos-juego/alertometro_bajo.png';
    }
  }

  ngOnInit() {

    this.puntuacion = this.navParams.data.puntuacion;
    this.tema = this.navParams.data.tema;
    this.displayTime = this.navParams.data.tiempo;
    this.riesgo = this.navParams.data.riesgo;

    // console.log('La puntuación fue de: ',this.puntuacion);
    // this.imagenRiesgo(this.riesgo);

    if (this.tema === 'recl') {
      this.tema = 'Reclutamiento, Uso y Utilización de Niños, Niñas y Adolescentes';
    } else if (this.tema === 'expl') {
      this.tema = 'Explotación Sexual y Comercial de Niños, Niñas y Adolescentes - ESCNNA';
    } else if (this.tema === 'viol') {
      this.tema = 'Violencia Sexual';
    } else if (this.tema === 'trab') {
      this.tema = 'Trabajo Infantil';
    } else if (this.tema === 'emba') {
      this.tema = 'Embarazo Adolescente';
    }

    // if (this.puntuacion <= 100) {
    //   this.imgRiesgo = '/assets/iconos-juego/alertometro_alto.png';
    //   this.riesgo = 'Alto';

    // } else if (this.puntuacion >= 101 && this.puntuacion <= 199) {
    //   this.imgRiesgo = '/assets/iconos-juego/alertometro_medio.png';
    //   this.riesgo = 'Medio';
    // } else if (this.puntuacion >= 200) {
    //   this.imgRiesgo = '/assets/iconos-juego/alertometro_bajo.png';
    //   this.riesgo = 'Bajo';
    // }

    // if (this.riesgo === 'Alto') {
    //   this.imgRiesgo = '/assets/iconos-juego/alertometro_alto.png';
    // } else if (this.riesgo === 'Medio') {
    //   this.imgRiesgo = '/assets/iconos-juego/alertometro_medio.png';
    // } else if (this.riesgo === 'bajo') {
    //   this.imgRiesgo = '/assets/iconos-juego/alertometro_bajo.png';
    // }
    console.log(this.imgRiesgo);
    // console.log(this.riesgo);
  }


}
