import { Component, OnInit, AfterViewInit } from '@angular/core';
import { StorageService, Usuario, Puntaje, Pregunta } from '../../services/storage.service';
import { Platform } from '@ionic/angular';
import { ActivatedRoute } from '@angular/router';
import { ModalController } from '@ionic/angular';
import { ModalPage } from '../modal/modal.page';
import { AlertController } from '@ionic/angular';
import { Router, NavigationEnd } from '@angular/router';
import { AudioService } from '../../services/audio.service';

@Component({
  selector: 'app-etapa-iv',
  templateUrl: './etapa-iv.page.html',
  styleUrls: ['./etapa-iv.page.scss'],
})
export class EtapaIvPage implements OnInit, AfterViewInit {

  constructor(
    private storageService: StorageService,
    private plt: Platform,
    private route: ActivatedRoute,
    private modalController: ModalController,
    public alertController: AlertController,
    private router: Router,
    private audio: AudioService ) {
      this.plt.ready().then(() => {
        this.isSoundOn = true;
        this.loadBoard();
        this.loadItems();
        this.loadPreguntas();
      });
      this.router.events.subscribe((ev) => {
        if (ev instanceof NavigationEnd) {
          const expression = '\/etapa-iv\/*';
          const regex = new RegExp(expression);
          if (ev.urlAfterRedirects.match(regex)) {
            this.cleanGame();
            this.loadBoard();
            this.loadPreguntas();
          }
        }
      });
  }

  usuarios: Usuario[] = [];
  numUsuario: boolean;
  tema: null;
  numrandom: number;
  correcto = 0;
  incorrecto = 0;
  timeInSeconds: any;
  time: any;
  hasStarted: boolean;
  hasFinished: boolean;
  nomimage: any;
  puntuacion = 0;
  numPreguntas = 0;
  riesgo: string;
  imgRiesgo: string;
  preguntasArr: string[] = [];
  preguntas: any;
  board: number[][] = [[]];

  // Sound
  isSoundOn: boolean;

  private staticBoard: number[][] = [
    [2, 3, 0, 8],
    [4, 10, 13, 6],
    [7, 14, 11, 1],
    [9, 15, 12, 5]
  ];

  private imgDict = {
    0: 'imagen1',
    1: 'imagen1',
    2: 'imagen2',
    3: 'imagen2',
    4: 'imagen3',
    5: 'imagen3',
    6: 'imagen4',
    7: 'imagen4',
    8: 'imagen5',
    9: 'imagen5',
    10: 'imagen6',
    11: 'imagen6',
    12: 'imagen7',
    13: 'imagen7',
    14: 'imagen8',
    15: 'imagen8',
  };

  private myImages: string[] = [
    '/assets/iconos-juego/sin_descubrir.png',
    '/assets/iconos-juego/sin_descubrir.png',
    '/assets/iconos-juego/sin_descubrir.png',
    '/assets/iconos-juego/sin_descubrir.png',
    '/assets/iconos-juego/sin_descubrir.png',
    '/assets/iconos-juego/sin_descubrir.png',
    '/assets/iconos-juego/sin_descubrir.png',
    '/assets/iconos-juego/sin_descubrir.png',
    '/assets/iconos-juego/sin_descubrir.png',
    '/assets/iconos-juego/sin_descubrir.png',
    '/assets/iconos-juego/sin_descubrir.png',
    '/assets/iconos-juego/sin_descubrir.png',
    '/assets/iconos-juego/sin_descubrir.png',
    '/assets/iconos-juego/sin_descubrir.png',
    '/assets/iconos-juego/sin_descubrir.png',
    '/assets/iconos-juego/sin_descubrir.png'
  ];

  random(mn, mx) {
    return Math.random() * (mx - mn) + mn;
  }

  loadBoard() {
    this.board = this.staticBoard;

    const boardSize = 4; // 4 by 4 board;
    const initialIndexes = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15];

    for (let i = 0; i < boardSize; i++) {
      for (let j = 0; j < boardSize; j++) {
        const idx = Math.floor(this.random(1, initialIndexes.length)) - 1;
        this.board[i][j] = initialIndexes[idx];
        initialIndexes.splice(idx, 1);
       }
    }
    // console.log('Board: ' + this.board); // Util para hacer debugging
  }

  ngAfterViewInit() {
    this.audio.preload('imageClick', 'assets/sounds/impactTin_medium_000.ogg');
    this.audio.preload('matchClick', 'assets/sounds/impactBell_heavy_000.ogg');
  }

  cleanGame() {
    this.numPreguntas = 0;
    this.preguntasArr = [];
    for (let i = 0; i < this.myImages.length; i++) {
      this.myImages[i] = '/assets/iconos-juego/sin_descubrir.png';
    }
    this.puntuacion = 0;
  }

  // READ
  loadItems() {
    this.storageService.getItems().then(usuarios => {
      this.usuarios = usuarios;

      if (!this.usuarios) {
        this.numUsuario = false;
        return;
    } else {
      this.numUsuario = true;
    }

    });
  }

  loadPreguntas() {
    fetch('./assets/data/' + this.tema + '.json')
      .then(res => res.json())
      .then(json => {
        this.preguntas = json;
      });
  }

  addEvent(imagen) {
    imagen = imagen as number;
    if (this.correcto === 1) {
      this.correcto = 0;
      this.incorrecto = 0;
    }

    if (this.incorrecto === 2) {
      this.incorrecto = 0;
      this.correcto = 0;
    }
    if (this.isSoundOn) {
      this.audio.play('imageClick');
    }

    const numberOfSlots = 15;
    for ( let i = 0; i < numberOfSlots + 1; ++i) {
      if (imagen === i) {
        if ((i % 2) === 0) {
          if ( (i + 1) <= numberOfSlots && this.myImages[i] === '/assets/iconos-juego/sin_descubrir.png') {
            this.myImages[i] = '/assets/iconos-juego/' + this.imgDict[i] + '.jpg';
            if (this.myImages[i + 1] === '/assets/iconos-juego/' +  this.imgDict[i] + '.jpg') {
              this.correcto += 1;
            } else {
              this.incorrecto += 1;
            }
          } else if (this.myImages[i] === '/assets/iconos-juego/' +  this.imgDict[i] + '.jpg') {
            this.myImages[i] = '/assets/iconos-juego/' +  this.imgDict[i] + '.jpg';
          } else {
            this.myImages[i] = '/assets/iconos-juego/sin_descubrir.png';
          }
        } else {
          if (this.myImages[i] === '/assets/iconos-juego/sin_descubrir.png') {
            this.myImages[i] = '/assets/iconos-juego/' +  this.imgDict[i] + '.jpg';
            if (this.myImages[i - 1] === '/assets/iconos-juego/' +  this.imgDict[i] + '.jpg') {
              this.correcto += 1;
            } else {
              this.incorrecto += 1;
            }
          } else if (this.myImages[i] === '/assets/iconos-juego/' +  this.imgDict[i] + '.jpg') {
            this.myImages[i] = '/assets/iconos-juego/' +  this.imgDict[i] + '.jpg';
          } else {
            this.myImages[i] = '/assets/iconos-juego/sin_descubrir.png';
          }
        }
        break;
      }
    }

    if (this.incorrecto === 2) {
      for (let i = 0; i < numberOfSlots; i = i + 2) {
        if (this.myImages[i] === '/assets/iconos-juego/' +  this.imgDict[i] + '.jpg' &&
            this.myImages[i + 1] === '/assets/iconos-juego/' +  this.imgDict[i] + '.jpg') {
          this.myImages[i] = '/assets/iconos-juego/' +  this.imgDict[i] + '.jpg';
          this.myImages[i + 1] = '/assets/iconos-juego/' +  this.imgDict[i] + '.jpg';
        } else {
          this.myImages[i] = '/assets/iconos-juego/sin_descubrir.png';
          this.myImages[i + 1] = '/assets/iconos-juego/sin_descubrir.png';
        }
      }
    }

    if (this.correcto === 1) {
      if (this.isSoundOn) {
        this.audio.play('matchClick');
      }
      this.openModal();
    }

    // console.log("Correcto: ",this.correcto);
    // console.log("Incorrecto: ",this.incorrecto);
    return this.correcto;
  }

  getPregunta() {
    const idx = Math.floor(this.random(1, this.preguntas.length)) - 1;

    const pregunta: Pregunta = {
      randomPreg: this.preguntas[idx].tPregunta,
      resCorrecta: this.preguntas[idx].rCorrecta,
      resRiesgo: this.preguntas[idx].riesgo,
      orientacion: this.preguntas[idx].orientacion,
      puntaje: 10
    };
    this.preguntas.splice(idx, 1);
    return pregunta;
  }

  async openModal() {
    let pregunta: Pregunta = this.getPregunta() as Pregunta;

    const modal = await this.modalController.create({
      component: ModalPage,
      componentProps: {
        tema: this.tema,
        pregunta
      }
    });

    modal.onDidDismiss().then((dataReturned) => {
      if ( dataReturned ) {
        pregunta = dataReturned.data.pregunta;
        this.presentAlert(pregunta.puntaje);
        if ( pregunta.orientacion ) {
          this.preguntasArr.push(pregunta.orientacion);
        }
      }
    });

    return await modal.present();
  }

  async openModalPuntaje() {
    const puntaje: Puntaje = {
      puntuacion: this.puntuacion,
      tema: this.tema,
      riesgo: this.riesgo,
      orientacion: this.preguntasArr
    };
    this.router.navigateByUrl('/modal-puntaje', {state :  puntaje});
  }

 toggleSound() {
   this.isSoundOn = !this.isSoundOn;
 }

 async presentAlert(puntaje) {
    this.puntuacion += puntaje;
    this.numPreguntas += 1;
    if (this.numPreguntas !== 8) {
      const alert = await this.alertController.create({
      header: '',
      subHeader: '',
      message: 'Tú puntaje adquirido por esta pregunta es:<br /> <center>' + puntaje + ' puntos</center>',
      buttons: ['Continuar'],
      cssClass: 'alertCustomCss'
      });
      await alert.present();
    } else {
      if (this.puntuacion <= 100) {
        this.riesgo = 'Alto';
      } else if (this.puntuacion >= 101 && this.puntuacion <= 199) {
        this.riesgo = 'Medio';
      } else if (this.puntuacion >= 200) {
        this.riesgo = 'Bajo';
      }
      this.openModalPuntaje();
    }
    console.log('Número de preguntas: ' + this.numPreguntas);
  }

  ngOnInit() {
    const temaId = 'tema';
    this.tema = this.route.snapshot.params[temaId];
    this.loadBoard();
    this.loadPreguntas();
  }

}
