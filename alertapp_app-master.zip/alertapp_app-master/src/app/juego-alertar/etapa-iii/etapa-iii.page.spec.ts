import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EtapaIiiPage } from './etapa-iii.page';

describe('EtapaIiiPage', () => {
  let component: EtapaIiiPage;
  let fixture: ComponentFixture<EtapaIiiPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EtapaIiiPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EtapaIiiPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
