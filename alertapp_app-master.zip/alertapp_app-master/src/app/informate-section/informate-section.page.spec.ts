import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InformateSectionPage } from './informate-section.page';

describe('InformateSectionPage', () => {
  let component: InformateSectionPage;
  let fixture: ComponentFixture<InformateSectionPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InformateSectionPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InformateSectionPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
