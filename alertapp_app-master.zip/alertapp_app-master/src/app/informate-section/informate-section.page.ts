import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';


@Component({
  selector: 'app-informate-section',
  templateUrl: './informate-section.page.html',
  styleUrls: ['./informate-section.page.scss'],
})
export class InformateSectionPage implements OnInit {

  constructor(private router: Router) { }

  toNoticiaOpen(){
    this.router.navigateByUrl("/noticia-open");
  }

  toNoticiaOpenOne(){
    this.router.navigateByUrl("/noticia-open-one");
  }

  toNoticiaOpenTwo(){
    this.router.navigateByUrl("/noticia-open-two");
  }

  toNoticiaOpenThree(){
    this.router.navigateByUrl("/noticia-open-three");
  }

  toNoticiaOpenFour(){
    this.router.navigateByUrl("/noticia-open-four");
  }

  ngOnInit() {
  }

}
