import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AprendeSatmedTrabajoInfantilPage } from './aprende-satmed-trabajo-infantil.page';

describe('AprendeSatmedTrabajoInfantilPage', () => {
  let component: AprendeSatmedTrabajoInfantilPage;
  let fixture: ComponentFixture<AprendeSatmedTrabajoInfantilPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AprendeSatmedTrabajoInfantilPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AprendeSatmedTrabajoInfantilPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
