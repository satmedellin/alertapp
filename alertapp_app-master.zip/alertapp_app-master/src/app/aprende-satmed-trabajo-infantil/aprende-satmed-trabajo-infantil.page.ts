import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController } from '@ionic/angular';

@Component({
  selector: 'app-aprende-satmed-trabajo-infantil',
  templateUrl: './aprende-satmed-trabajo-infantil.page.html',
  styleUrls: ['./aprende-satmed-trabajo-infantil.page.scss'],
})
export class AprendeSatmedTrabajoInfantilPage implements OnInit {

  constructor(public alertController: AlertController, private router: Router) { }

  async constitucion() {
    const alert = await this.alertController.create({
      header: 'Constitución Política de Colombia',
      subHeader: 'Norma Nacional',
      message: 'en su artículo 44 establece que los niños, niñas y adolescentes deben ser protegidos contra toda forma de explotación laboral o económica, trabajos riesgosos y que sus derechos prevalecen sobre los derechos de los demás y en concordancia el artículo 45 de la Constitución Política  establece un margen de protección al adolescente y a su formación integral, en el marco del bloque de constitucionalidad y la legislación vigente.',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }
  async ley12() {
    const alert = await this.alertController.create({
      header: 'Ley 12 de 1991',
      subHeader: 'Norma Nacional',
      message: 'Se aprobó la Convención Nacional sobre los Derechos del Niño, la cual tiene como objetivo primordial que las naciones del mundo reconozcan que los niños tienen derecho a cuidados y asistencia especiales para el pleno y armonioso desarrollo de su personalidad y que deben crecer en el seno de una familia, dentro de un ambiente de felicidad, amor y comprensión. Igualmente convoca a los Estados Partes a que se comprometan a proteger a la infancia contra la explotación económica y contra el desempeño de cualquier trabajo que pueda ser peligroso, entorpecer su educación, o ser nocivo para su salud y para su desarrollo físico, mental, espiritual, moral o social.',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }
  async dec859() {
    const alert = await this.alertController.create({
      header: 'Decreto 859 de 1995',
      subHeader: 'Norma Nacional',
      message: '“Por el cual se crea el Comité Interinstitucional para la erradicación de Trabajo Infantil y la Protección del Menor Trabajador – CIETI”. organismo encargado de: asesorar, coordinar y proponer políticas y programas, a nivel nacional, departamental y municipal, tendientes a mejorar la condición social del menor trabajador, desestimular la utilización de la mano de obra infantil; y fortalecer la coordinación y concertación entre las instituciones públicas y privadas, para definir alternativas y estrategias para intervenir la problemática, entre otras funciones asignadas.',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }
  async ley515() {
    const alert = await this.alertController.create({
      header: 'Ley 515 de 1999 Convenio 138 de la OIT',
      subHeader: 'Norma Nacional',
      message: 'Por medio de la cual se aprueba el "Convenio 138 sobre la Edad Mínima de Admisión de Empleo", adoptada por la 58ª Reunión de la Conferencia General de la Organización Nacional del Trabajo, Ginebra, Suiza, el veintiséis (26) de junio de mil novecientos setenta y tres (1973)”.',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }
  async ley704() {
    const alert = await this.alertController.create({
      header: 'Ley 704 de 2001 Convenio 182 de la OIT',
      subHeader: 'Norma Nacional',
      message: '“Por medio de la cual se aprueba el "Convenio 182 sobre la prohibición de las peores formas de trabajo infantil y la acción inmediata para su eliminación", adoptado por la Octogésima Séptima (87a.) Reunión de la Conferencia General de la Organización Nacional del Trabajo, O.I.T., Ginebra, Suiza, el diecisiete (17) de junio de mil novecientos noventa y nueve (1999)”',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }
  async ley1098() {
    const alert = await this.alertController.create({
      header: 'Ley 1098 de 2006. Ley de Infancia y adolescencia',
      subHeader: 'Norma Nacional',
      message: 'Establece en su artículo 117 la prohibición de realizar trabajos peligrosos y nocivos a las personas menores de 18 años señalando que el Ministerio del Trabajo en colaboración con el Instituto Colombiano de Bienestar Familiar, establecerán la clasificación de dichas actividades de acuerdo al nivel de peligro y nocividad que impliquen para los adolescentes autorizados para trabajar y la publicarán cada dos años periódicamente en distintos medios de comunicación. Que la ley en mención, en su artículo 20, numerales 12 y 13, establece que los niños, niñas y adolescentes serán protegidos contra el trabajo que por su naturaleza o por las condiciones en que se lleva a cabo pueda afectar su salud, integridad y seguridad o impedir el derecho a la educación y contra las peores formas de trabajo infantil, de conformidad con el Convenio 182 de la OIT. Así mismo, el artículo 35 ibídem define como edad mínima de admisión al trabajo los quince (15) años, determina que los adolescentes entre los quince (15) y diecisiete (17) años de edad (menores de 18 años) requieren la respectiva autorización expedida por el Inspector de Trabajo o, en su defecto, por el Ente Territorial Local, consagra que los adolescentes autorizados para trabajar tienen derecho a la formación y especialización que los habilite para ejercer libremente una ocupación, arte, oficio o profesión y a recibirla durante el ejercicio de su actividad laboral y dispone que los adolescentes gozarán de las protecciones laborales consagradas en el régimen laboral colombiano, en las normas que lo complementan y en los tratados y convenios internacionales ratificados por Colombia, que forman parte del Bloque de Constitucionalidad.',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }
  async ley1622() {
    const alert = await this.alertController.create({
      header: 'Ley 1622 de 2013',
      subHeader: 'Norma Nacional',
      message: '“Por medio de la cual se expide el estatuto de ciudadanía juvenil y se dictan otras disposiciones"',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }
  async res1796() {
    const alert = await this.alertController.create({
      header: 'Resolución 1796 De 2018',
      subHeader: 'Norma Nacional',
      message: 'Por la cual se actualiza el listado de las actividades peligrosas que por su naturaleza o condiciones de trabajo son nocivas para la salud e integridad física o psicológica de los menores de 18 años y se dictan otras disposiciones.',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }

  toSatmedThemes(){
    this.router.navigateByUrl("/aprende-satmed-section");
  }

  ngOnInit() {
  }

}
