import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full'
  },
  {
    path: 'home',
    loadChildren: () => import('./home/home.module').then(m => m.HomePageModule)
  },
  {
    path: 'list',
    loadChildren: () => import('./list/list.module').then(m => m.ListPageModule)
  },
  { path: 'aprende-satmed-section', loadChildren: './aprende-satmed-section/aprende-satmed-section.module#AprendeSatmedSectionPageModule' },
  { path: 'aprende-satmed-violencia-sexual', loadChildren: './aprende-satmed-violencia-sexual/aprende-satmed-violencia-sexual.module' +
                                                           '#AprendeSatmedViolenciaSexualPageModule' },
  { path: 'informate-section', loadChildren: './informate-section/informate-section.module#InformateSectionPageModule' },
  { path: 'emergencia-section', loadChildren: './emergencia-section/emergencia-section.module#EmergenciaSectionPageModule' },
  { path: 'concentrese-images', loadChildren: './concentrese-images/concentrese-images.module#ConcentreseImagesPageModule' },
  { path: 'aprende-satmed-escnna', loadChildren: './aprende-satmed-escnna/aprende-satmed-escnna.module#AprendeSatmedEscnnaPageModule' },
  { path: 'aprende-satmed-prea', loadChildren: './aprende-satmed-prea/aprende-satmed-prea.module#AprendeSatmedPreaPageModule' },
  { path: 'aprende-satmed-trabajo-infantil', loadChildren: './aprende-satmed-trabajo-infantil/aprende-satmed-trabajo-infantil.module' +
                                                           '#AprendeSatmedTrabajoInfantilPageModule' },
  { path: 'aprende-satmed-reclutamiento', loadChildren: './aprende-satmed-reclutamiento/aprende-satmed-reclutamiento.module' +
                                                        '#AprendeSatmedReclutamientoPageModule' },
  { path: 'noticia-open', loadChildren: './noticia-open/noticia-open.module#NoticiaOpenPageModule' },
  { path: 'noticia-open-one', loadChildren: './noticia-open-one/noticia-open-one.module#NoticiaOpenOnePageModule' },
  { path: 'noticia-open-two', loadChildren: './noticia-open-two/noticia-open-two.module#NoticiaOpenTwoPageModule' },
  { path: 'noticia-open-three', loadChildren: './noticia-open-three/noticia-open-three.module#NoticiaOpenThreePageModule' },
  { path: 'noticia-open-four', loadChildren: './noticia-open-four/noticia-open-four.module#NoticiaOpenFourPageModule' },
  { path: 'emergencia-violencia-sexual', loadChildren: './emergencia-violencia-sexual/emergencia-violencia-sexual.module' +
                                                       '#EmergenciaViolenciaSexualPageModule' },
  { path: 'emergencia-escnna', loadChildren: './emergencia-escnna/emergencia-escnna.module#EmergenciaEscnnaPageModule' },
  { path: 'emergencia-reclutamiento', loadChildren: './emergencia-reclutamiento/emergencia-reclutamiento.module' +
                                                    '#EmergenciaReclutamientoPageModule' },
  { path: 'emergencia-trabajo-infantil', loadChildren: './emergencia-trabajo-infantil/emergencia-trabajo-infantil.module' +
                                                       '#EmergenciaTrabajoInfantilPageModule' },
  { path: 'emergencia-prea', loadChildren: './emergencia-prea/emergencia-prea.module#EmergenciaPreaPageModule' },
  { path: 'aliados-satmed', loadChildren: './aliados-satmed/aliados-satmed.module#AliadosSatmedPageModule' },
  { path: 'acercade-satmed', loadChildren: './acercade-satmed/acercade-satmed.module#AcercadeSatmedPageModule' },
  { path: 'terminos-condiciones', loadChildren: './terminos-condiciones/terminos-condiciones.module#TerminosCondicionesPageModule' },
  { path: 'cuenta', loadChildren: './cuenta/cuenta.module#CuentaPageModule' },
  { path: 'juego-alertar', loadChildren: './juego-alertar/juego-alertar.module#JuegoAlertarPageModule' },
  { path: 'etapa-ii', loadChildren: './juego-alertar/etapa-ii/etapa-ii.module#EtapaIiPageModule' },
  { path: 'etapa-iii', loadChildren: './juego-alertar/etapa-iii/etapa-iii.module#EtapaIiiPageModule' },
  { path: 'etapa-iv/:tema', loadChildren: './juego-alertar/etapa-iv/etapa-iv.module#EtapaIvPageModule' },
  { path: 'etapa-iv', loadChildren: './juego-alertar/etapa-iv/etapa-iv.module#EtapaIvPageModule' },
  { path: 'modal-puntaje', loadChildren: './juego-alertar/modal-puntaje/modal-puntaje.module#ModalPuntajePageModule' },
  { path: 'puntaje', loadChildren: './juego-alertar/puntaje/puntaje.module#PuntajePageModule' },
  { path: 'coronavirus-covid19', loadChildren: './coronavirus-covid19/coronavirus-covid19.module#CoronavirusCovid19PageModule' }
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule {}
