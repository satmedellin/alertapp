import { Component, ViewChildren, QueryList, OnDestroy } from '@angular/core';
import { Platform, IonRouterOutlet, AlertController } from '@ionic/angular';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { Router } from '@angular/router';

// para salir de la app video: https://www.youtube.com/watch?v=wKqYqv8S7o0&t=33s
// para salir de la app Ejemplo: https://github.com/ClickerVinod/Ionic4ExitAlert/blob/master/src/app/app.component.ts


@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss']
})
export class AppComponent implements OnDestroy {

  // for storing the returned subscription
  backButtonSubscription;
  @ViewChildren(IonRouterOutlet) routerOutlets: QueryList<IonRouterOutlet>;

  public appPages = [
    {
      title: 'Inicio',
      url: '/home',
      icon: 'home'
    },
    {
      title: 'Últimas noticias',
      url: '/informate-section',
      icon: 'paper'
    },
    {
      title: 'Aprende con el SATMED',
      url: '/aprende-satmed-section',
      icon: 'trophy'
    },
    {
      title: 'Ruta de alerta',
      url: '/juego-alertar',
      icon: 'basketball'
    },
    {
      title: 'Orientación temprana',
      url: '/emergencia-section',
      icon: 'help-buoy'
    },
    {
      title: 'Organizaciones aliadas',
      url: '/aliados-satmed',
      icon: 'contacts'
    },
    {
      title: 'Acerca del SATMED',
      url: '/acercade-satmed',
      icon: 'checkmark-circle-outline'
    },
    {
      title: 'Términos y condiciones',
      url: '/terminos-condiciones',
      icon: 'list-box'
    }
  ];

  constructor(
    private platform: Platform,
    public router: Router,
    public alertController: AlertController,
    private splashScreen: SplashScreen,
    private statusBar: StatusBar
  ) {
    this.initializeApp();
  }

  initializeApp() {
    this.platform.ready().then(() => {
      this.statusBar.styleDefault();
      this.backButtonEvent();
      this.splashScreen.hide();
    });
  }

  backButtonEvent() {
    this.backButtonSubscription = this.platform.backButton.subscribe(async () => {
      this.routerOutlets.forEach((outlet: IonRouterOutlet) => {
        if (outlet && outlet.canGoBack()) {
          outlet.pop();
        } else if ( this.router.url === '/home' ) {
          this.presentAlertConfirm();
        }
      });
    });
  }

  async presentAlertConfirm() {
    const alert = await this.alertController.create({
      header: 'Salir de Alertapp',
      message: '¿Deseas salir de Alertapp?',
      buttons: [
        {
          text: 'No',
          role: 'cancel',
          cssClass: 'secondary',
          handler: (blah) => {
            console.log('Confirm Cancel: blah');
          }
        }, {
          text: 'Si, salir',
          handler: () => {
            console.log('Confirmado');
            const myApp = 'app';
            navigator[myApp].exitApp();
          }
        }
      ]
    });
    await alert.present();
  }

  // Called when view is left
  ngOnDestroy() {
    // Unregister the custom back button action for this page
    this.backButtonSubscription.unsubscribe();
  }

}
