import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-acercade-satmed',
  templateUrl: './acercade-satmed.page.html',
  styleUrls: ['./acercade-satmed.page.scss'],
})
export class AcercadeSatmedPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
