import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';

import { IonicModule } from '@ionic/angular';

import { CoronavirusCovid19Page } from './coronavirus-covid19.page';

const routes: Routes = [
  {
    path: '',
    component: CoronavirusCovid19Page
  }
];

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RouterModule.forChild(routes)
  ],
  declarations: [CoronavirusCovid19Page]
})
export class CoronavirusCovid19PageModule {}
