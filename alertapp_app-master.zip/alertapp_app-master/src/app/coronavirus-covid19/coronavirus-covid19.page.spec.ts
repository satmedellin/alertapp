import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CoronavirusCovid19Page } from './coronavirus-covid19.page';

describe('CoronavirusCovid19Page', () => {
  let component: CoronavirusCovid19Page;
  let fixture: ComponentFixture<CoronavirusCovid19Page>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CoronavirusCovid19Page ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CoronavirusCovid19Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
