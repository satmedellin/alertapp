import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-coronavirus-covid19',
  templateUrl: './coronavirus-covid19.page.html',
  styleUrls: ['./coronavirus-covid19.page.scss'],
})
export class CoronavirusCovid19Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
