import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-emergencia-trabajo-infantil',
  templateUrl: './emergencia-trabajo-infantil.page.html',
  styleUrls: ['./emergencia-trabajo-infantil.page.scss'],
})
export class EmergenciaTrabajoInfantilPage implements OnInit {

  constructor(private router: Router) { }

  toSatmedHelp(){
    this.router.navigateByUrl("/emergencia-section");
  }

  ngOnInit() {
  }

}
