import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-aprende-satmed-section',
  templateUrl: './aprende-satmed-section.page.html',
  styleUrls: ['./aprende-satmed-section.page.scss'],
})
export class AprendeSatmedSectionPage implements OnInit {

  constructor(private router: Router) { }

  toPreaTheme() {
    this.router.navigateByUrl("/aprende-satmed-prea");
  }

  toVsxTheme(){
    this.router.navigateByUrl("/aprende-satmed-violencia-sexual");
  }

  toEscnnaTheme(){
    this.router.navigateByUrl("/aprende-satmed-escnna");
  }

  toTrabajoTheme(){
    this.router.navigateByUrl("/aprende-satmed-trabajo-infantil");
  }

  toRecTheme(){
    this.router.navigateByUrl("/aprende-satmed-reclutamiento");
  }

  ngOnInit() {
  }

}
