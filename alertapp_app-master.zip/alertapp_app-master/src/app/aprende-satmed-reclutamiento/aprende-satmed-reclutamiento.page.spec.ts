import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AprendeSatmedReclutamientoPage } from './aprende-satmed-reclutamiento.page';

describe('AprendeSatmedReclutamientoPage', () => {
  let component: AprendeSatmedReclutamientoPage;
  let fixture: ComponentFixture<AprendeSatmedReclutamientoPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AprendeSatmedReclutamientoPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AprendeSatmedReclutamientoPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
