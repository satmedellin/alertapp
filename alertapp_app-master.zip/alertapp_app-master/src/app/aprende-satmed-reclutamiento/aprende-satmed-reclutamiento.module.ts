import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';

import { IonicModule } from '@ionic/angular';

import { AprendeSatmedReclutamientoPage } from './aprende-satmed-reclutamiento.page';

const routes: Routes = [
  {
    path: '',
    component: AprendeSatmedReclutamientoPage
  }
];

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RouterModule.forChild(routes)
  ],
  declarations: [AprendeSatmedReclutamientoPage]
})
export class AprendeSatmedReclutamientoPageModule {}
