import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController } from '@ionic/angular';

@Component({
  selector: 'app-aprende-satmed-reclutamiento',
  templateUrl: './aprende-satmed-reclutamiento.page.html',
  styleUrls: ['./aprende-satmed-reclutamiento.page.scss'],
})
export class AprendeSatmedReclutamientoPage implements OnInit {

  constructor(public alertController: AlertController, private router: Router) { }

  async protConvGine() {
    const alert = await this.alertController.create({
      header: 'Protocolo Adicional a los Convenios de Ginebra del 12 de Agosto de 1949 relativo a la protección de las víctimas de los conflictos armados sin carácter internacional. Aprobado por la Ley 171 de 1994. Entró en vigor el 15 de Febrero de 1996',
      subHeader: 'Norma Internacional',
      message: 'Los Convenios de Ginebra señalan que todas las personas civiles deben ser protegidas, en especial los niños. El Protocolo II, a través de su artículo 4, reafirma el compromiso de protección a los niños. De otra parte, prohíbe que los menores de 15 años sean reclutados por fuerzas o grupos armados y su participación en hostilidades.',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }
  async pactIntDerCiPo() {
    const alert = await this.alertController.create({
      header: 'Pacto Internacional de Derechos Civiles y Políticos, 1966. Aprobado por la Ley 74 de 1968. Entró en vigor el 23 de marzo de 1976',
      subHeader: 'Norma Internacional',
      message: 'Este Pacto, a través de su artículo 24, señala el derecho que tiene todo niño a ser protegido por su familia, la sociedad y el Estado. Entre los derechos que consagra están: el derecho a la vida, la libertad, la seguridad, la igualdad, la prohibición de tortura, los tratos crueles e inhumanos; al igual que la esclavitud, la servidumbre o los trabajos forzados.',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }
  async pactIntDerEco() {
    const alert = await this.alertController.create({
      header: 'Pacto Internacional de Derechos Económicos, Sociales y Culturales, 1966. Aprobado por la Ley 74 de 1968. Entró en vigor el 3 de enero de 1976',
      subHeader: 'Norma Internacional',
      message: 'El artículo 10 establece que se deben adoptar medidas especiales de protección y asistencia en favor de todos los niños y adolescentes, sin discriminación alguna por razón de filiación o cualquier otra condición. Adicionalmente, el Pacto señala que esta población debe ser protegida de la explotación económica y social; al igual que de su empleo en trabajos nocivos para su moral y salud, o en los cuales peligre su vida o se corra el riesgo de perjudicar su desarrollo normal. Por tanto, los Estados deben establecer límites de edad por debajo de los cuales quede prohibido y sancionado por la ley el empleo a sueldo de mano de obra infantil.',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }
  async convAmeDerHum() {
    const alert = await this.alertController.create({
      header: 'Convención Americana de Derechos Humanos – Pacto de San José, 1969. Incorporada al orden jurídico interno por la Ley 16 de 1972. Ratificada el 31 de julio de 1973. Entró en vigor el 18 de julio de 1978',
      subHeader: 'Norma Internacional',
      message: 'Entre los derechos que se consagran en la Convención está el derecho a la vida. En el marco de este derecho, se prohíbe “la pena de muerte a persona que, en el momento de la comisión del delito, tuviere menos de dieciocho años de edad”. Su artículo 19 se refiere explícitamente a los “Derechos del Niño”, señalando que “todo niño tiene derecho a las medidas de protección que su condición de menor requieren por parte de su familia, de la sociedad y del Estado”.',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }
  async convDerNi1989() {
    const alert = await this.alertController.create({
      header: 'Convención sobre los Derechos del Niño, CDN, 1989. Aprobada por la Ley 12 de 1991. Entró en vigor el 27 de febrero de 1991. Colombia estableció una reserva a los numerales 2 y 3 del Artículo 38',
      subHeader: 'Norma Internacional',
      message: 'La Convención en su artículo 38 recuerda la obligación estatal de proteger a quienes no han cumplido los 15 años de edad de participar directamente en las hostilidades; de abstenerse de reclutar a esta población y de adoptar todas las medidas posibles para asegurar la protección y el cuidado de los niños afectados por un conflicto armado. El artículo 39, por su parte, señala la obligación de adoptar medidas para promover la recuperación y la reintegración de los niños y niñas víctimas de los conflictos armados, “en un ambiente que fomente la salud, el respeto de sí mismo y la dignidad del niño”.',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }
  async conv138() {
    const alert = await this.alertController.create({
      header: 'Convenio 138 de la OIT, 1973, sobre la edad mínima de admisión al empleo. Aprobado por la Ley 515 de 1999. Entró en vigencia el 2 de febrero de 2001 para Colombia',
      subHeader: 'Norma Internacional',
      message: 'El primer artículo compromete a todos sus miembros a asegurar la abolición efectiva del trabajo de los niños y a elevar progresivamente la edad mínima de admisión al empleo o a un trabajo que haga posible el más completo desarrollo físico y mental de los niños, niñas y adolescentes.',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }
  async con182() {
    const alert = await this.alertController.create({
      header: 'Convenio 182 de la OIT, 1999, referente a las peores formas de trabajo infantil. Aprobado por la Ley 704 de 2001.',
      subHeader: 'Norma Internacional',
      message: 'El Convenio 182 de la OIT señala que el reclutamiento y utilización de niños es una expresión de las peores formas de trabajo infantil. Su artículo 6 dicta que se “deberán elaborar y poner en práctica programas de acción para eliminar, como medida prioritaria, las peores formas de trabajo infantil”.',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }
  async protoFacDerNino() {
    const alert = await this.alertController.create({
      header: 'Protocolo Facultativo de la Convención sobre los Derechos del Niño. Firmado el 6 de Septiembre de 2002. Aprobado por la Ley 833 de 2003. Declarada exequible mediante sentencia C-172 de 2004 de la Corte Constitucional, y promulgado por el Decreto 3966 de 2005',
      subHeader: 'Norma Internacional',
      message: 'Este protocolo estable que los Estados parte deben tomar todas las medidas para evitar que los menores de 18 años participen en confrontaciones armadas. Señala que grupos distintos a las Fuerzas Armadas no deben, en ninguna circunstancia, reclutar o utilizar a menores de 18 años en las hostilidades. De otro lado, impone la obligación a los Estados parte de prevenir el reclutamiento y utilización de menores de 18 años. Así mismo, presentar informes al Comité de los Derechos del Niño sobre la aplicación del Protocolo.',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }
  async estRoma() {
    const alert = await this.alertController.create({
      header: 'Estatuto de Roma de la Corte Penal Internacional, CPI, 1998. Aprobado por la Ley 742 de 2002, ratificado el 5 de Agosto de 2002 y entró en vigor el 1 de Noviembre de 2002',
      subHeader: 'Norma Internacional',
      message: 'La CPI tiene competencia sobre los siguientes crímenes: Genocidio, Lesa Humanidad, Guerra y Agresión (Artículo 5). En su artículo 8 establece como una de las violaciones graves de las leyes y usos aplicables en los conflictos el “reclutar o alistar a niños menores de 15 años en las fuerzas armadas nacionales o utilizarlos para participar activamente en las hostilidades”.',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }
  async convNaUni() {
    const alert = await this.alertController.create({
      header: 'Convención de las Naciones Unidas contra la Delincuencia Organizada Transnacional. Ley 800 de 2003 aprobó la citada convención y el Protocolo para Prevenir, Reprimir y Sancionar la Trata de Personas, Especialmente Mujeres y Niños, que Complementa la Convención de las Naciones Unidas contra la Delincuencia Organizada Transnacional',
      subHeader: 'Norma Internacional',
      message: 'La Convención busca promover la cooperación para prevenir y combatir más eficazmente la delincuencia organizada transnacional. Contiene la definición de grupo delictivo organizado que se estructura para cometer delitos graves. La noción de estructurado señala que dicho grupo no se ha formado fortuitamente y, por tanto, presenta una estructura desarrollada. Establece, además, que por delitos graves se debe entender la ocurrencia de conductas punibles con una privación de la libertad máxima de al menos cuatro años.',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }
  async dec3043() {
    const alert = await this.alertController.create({
      header: 'Decreto 3043 de 2006',
      subHeader: 'Norma Nacional',
      message: 'Crea la ACR y le señala entre sus funciones la de: “acompañar y asesorar al Instituto Colombiano de Bienestar Familiar en la definición de políticas y estrategias relacionadas con la prevención del reclutamiento, la desvinculación y reintegración de los menores de edad a grupos armados organizados al margen de la ley”.',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }
  async dec4690() {
    const alert = await this.alertController.create({
      header: 'Decreto 4690 de 2007',
      subHeader: 'Norma Nacional',
      message: 'Crea la Comisión Intersectorial, señala las instituciones que la conforman y enuncia sus principales funciones. El objeto de la Comisión es “articular y orientar la ejecución de las acciones para prevenir el reclutamiento y utilización de niños, niñas, adolescentes y jóvenes por grupos organizados al margen de la ley”.',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }
  async ley1450() {
    const alert = await this.alertController.create({
      header: 'Ley 1450 de 2011',
      subHeader: 'Norma Nacional',
      message: 'En el cual, se plantea la priorización de los jóvenes para evitar su vinculación o reincidencia en la delincuencia, así como para fomentar su resocialización, lo cual, dará impulso al logro de los objetivos propuestos en el documento CONPES 3673 y fomentará espacios y prácticas protectoras para niños, niñas y adolescentes en zonas de riesgo de utilización y reclutamiento.',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }
  async compes3673() {
    const alert = await this.alertController.create({
      header: 'Documento CONPES 3673 de 2010',
      subHeader: 'Norma Nacional',
      message: 'Este CONPES busca que con la articulación de planes de acción de entidades nacionales, de investigación judicial y de control se incida directa o indirectamente sobre las causas y factores de riesgo identificados que facilitan el reclutamiento y utilización de niños, niñas y adolescentes, de forma tal que esta población permanezcan en sus entornos familiares, comunitarios y escolares, los cuales deberán irse transformando en el mediano, en el corto y en el inmediato plazo, en entornos realmente protectores y garantes de sus derechos.',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }
  async ley1448() {
    const alert = await this.alertController.create({
      header: 'Ley 1448 de 2011',
      subHeader: 'Norma Nacional',
      message: 'La Ley 1448 de 2011, conocida como Ley de Victimas, contiene todo un título concerniente a la protección integral de los niños, niñas y adolescentes víctimas de los hechos ocurridos a partir del 1 de Enero de 1985 como consecuencias de infracciones al Derecho Internacional Humanitario o de violaciones graves y manifiestas a las normas internacionales de Derechos Humanos. El Título VII está compuesto por once artículos a través de los cuales se consagran, entre otras disposiciones, los derechos de esta población como víctima, al igual que la obligatoriedad estatal de repararla integralmente, restablecer sus derechos; garantizar la indemnización a lugar, el acceso a la justicia y los procesos de construcción de convivencia y reconciliación. El Artículo 190, en particular, señala que todos los niños, niñas y adolescentes víctimas del reclutamiento, tendrán derecho a la reparación integral en los términos de la presente ley, al restablecimiento de sus derechos y a ingresar en los procesos de reintegración social y económica.',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }
  async ley1453() {
    const alert = await this.alertController.create({
      header: 'Ley 1453 de 2011',
      subHeader: 'Norma Nacional',
      message: 'La Ley 1453, conocida como Estatuto de Seguridad Ciudadana, se estructura a partir de ocho capítulos que contienen medidas de diverso orden para garantizar la seguridad ciudadana. Introduce nuevos tipos penales orientados a la protección integral de menores de 18 años y, por ende, a sancionar a quienes incurran en las conductas punibles de: i) tráfico de niños, niñas y adolescentes; ii) uso de menores de edad para la comisión de delitos y iii) explotación de menores.',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }
  async res1523() {
    const alert = await this.alertController.create({
      header: 'Resolución no. 1523 de febrero 23 de 2016 del ICBF',
      subHeader: 'Norma Nacional',
      message: 'Tiene como principal objetivo definir los elementos de tipo contextual, cultural, físico, psicológico, ecológico y familiar, entre otros, y los procedimientos que guiarán la asistencia y atención que se dará a la niñez y adolescencia víctima del conflicto armado colombiano, para garantizar el restablecimiento de sus derechos, como mecanismo de acompañamiento al proceso de la reparación integral que contempla la Ley 1448 de 2011 (Ley de víctimas y restitución de tierras).',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }
  async dec1434() {
    const alert = await this.alertController.create({
      header: 'Decreto 1434 de 2018',
      subHeader: 'Norma Nacional',
      message: 'El presente decreto tiene por objeto adoptar la “Línea de política pública de prevención del reclutamiento, utilización, uso y violencia sexual en contra de niños, niñas y adolescentes por parte de los grupos armados organizados y los grupos delincuenciales organizados”, y sus anexos, garantizando la prevalencia y goce efectivo de los derechos y la protección integral por parte del Estado, la sociedad y la familia, en el marco de los compromisos internacionales asumidos por Colombia.',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }

  toSatmedThemes(){
    this.router.navigateByUrl("/aprende-satmed-section");
  }

  ngOnInit() {
  }

}
