import { Component, ViewChild, OnInit } from '@angular/core';
import { StorageService, Usuario } from '../services/storage.service';
import { Platform, ToastController, IonList } from '@ionic/angular';

import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import { Router, NavigationEnd } from '@angular/router';

@Component({
  selector: 'app-cuenta',
  templateUrl: './cuenta.page.html',
  styleUrls: ['./cuenta.page.scss'],
})

export class CuentaPage implements OnInit {
  public formGroup: FormGroup;

  usuarios: Usuario[] = [];

  newUsuario: Usuario = {} as Usuario;

  @ViewChild('mylist', {static: false}) mylist: IonList;
  numUsuario: boolean;

  constructor(private storageService: StorageService, private plt: Platform, private toastController: ToastController,
              private formBuilder: FormBuilder, private router: Router) {
    /*this.plt.ready().then(() => {
      this.loadItems();
    });*/
    this.router.events.subscribe((ev) => {
      if (ev instanceof NavigationEnd) {
        if (ev.urlAfterRedirects === '/cuenta') {
          this.loadItems();
        }
      }
    });
  }

  // CREATE
  addItem() {
    this.newUsuario.id = Date.now();

    this.storageService.addItem(this.newUsuario).then( () => {
      this.newUsuario = {} as Usuario;
      // this.showToast('¡Has creado tú usuario!');
      this.loadItems(); // Or add it to the array directly
      this.irJuegoAlertar();
    });
  }

  // READ
  loadItems() {
    this.storageService.getItems().then(usuarios => {
      this.usuarios = usuarios;
      if (!this.usuarios) {
          this.numUsuario = false;
          // console.log("Es false cuenta");
      } else {
        this.numUsuario = true;
        this.irJuegoAlertar();
        // console.log("Es true cuenta");
      }

    });
  }

  irJuegoAlertar() {
    this.router.navigateByUrl('/juego-alertar');
  }

  // UPDATE
  updateItem(usuario: Usuario) {
    usuario.nombre = `UPDATED: ${usuario.nombre}`;
    this.storageService.updateItem(usuario).then( () => {
      this.showToast('!Usuario actualizado!');
      this.mylist.closeSlidingItems(); // Fix or sliding is stuck afterwards
      this.loadItems(); // Or update it inside the array directly
    });
  }

  // Helper
  async showToast(msg) {
    const toast = await this.toastController.create({
      message: msg,
      duration: 2000
    });
    toast.present();
  }

  ngOnInit() {
    this.buildForm();
    this.loadItems();
    console.log(this.numUsuario);
  }

  private buildForm() {
    this.formGroup = this.formBuilder.group({
      nombre: ['', [Validators.required, Validators.minLength(3)
      ]],
      edad: ['', [Validators.required, Validators.max(99)]],
      genero: ['', Validators.required]
    });
  }

  saveData() {
    console.log(this.formGroup.value);
  }

}
