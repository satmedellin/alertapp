import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AprendeSatmedEscnnaPage } from './aprende-satmed-escnna.page';

describe('AprendeSatmedEscnnaPage', () => {
  let component: AprendeSatmedEscnnaPage;
  let fixture: ComponentFixture<AprendeSatmedEscnnaPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AprendeSatmedEscnnaPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AprendeSatmedEscnnaPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
