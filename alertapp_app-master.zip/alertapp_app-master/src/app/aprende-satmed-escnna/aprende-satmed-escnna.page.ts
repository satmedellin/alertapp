import { Component, OnInit } from '@angular/core';
import { AlertController } from '@ionic/angular';
import { Router } from '@angular/router';

@Component({
  selector: 'app-aprende-satmed-escnna',
  templateUrl: './aprende-satmed-escnna.page.html',
  styleUrls: ['./aprende-satmed-escnna.page.scss'],
})
export class AprendeSatmedEscnnaPage implements OnInit {

  constructor(public alertController: AlertController, private router: Router) { }

  async elimiDiscMujer() {
    const alert = await this.alertController.create({
      header: 'Convención sobre la Eliminación de todas las formas de Discriminación contra la Mujer (CEDAW por sus siglas en inglés) Ratificada a través de la Ley 051 de 1981',
      subHeader: 'Norma Internacional',
      message: 'Compromete al Estado a impulsar medidas que aporten a la construcción de una cultura que respete plenamente los derechos de las mujeres, como una forma de discriminación que impide gravemente el goce sus derechos y libertades. Artículo 6. Los Estados Partes tomarán todas las medidas apropiadas, incluso de carácter legislativo, para suprimir todas las formas de trata de mujeres y explotación de la prostitución de la mujer. La Convención define como mecanismo de seguimiento de la CEDAW el Comité para la Eliminación de la Discriminación contra la Mujer.',
      buttons: ['¡Entendido!']
    });

    await alert.present();
  }

  async convDereNino() {
    const alert = await this.alertController.create({
      header: 'Convención de los Derechos del Niño – a (CDN) – 1989 Ratificada por ley 12 de 1991 El artículo 1',
      subHeader: 'Norma Internacional',
      message: 'El artículo 19° en su primer numeral, insta a los estados a adoptar “todas las medidas legislativas, administrativas, sociales y educativas apropiadas para proteger al niño contra toda forma de perjuicio o abuso físico o mental, descuido o trato negligente, malos tratos o explotación, incluido el abuso sexual, mientras el niño se encuentre bajo la custodia de los padres, de un representante legal o de cualquier otra persona que lo tenga a su cargo. El artículo 34° exige a los Estados Partes a dar protección a los niños, niñas y adolescentes contra todas las formas de explotación y abuso sexual. Otros artículos relacionados con la Explotación Sexual Comercial de Niños, Niñas y Adolescentes son el 11, 21, 32, 33, 35 y 36.',
      buttons: ['¡Entendido!']
    });

    await alert.present();
  }
  async protConDerNinez() {
    const alert = await this.alertController.create({
      header: 'Protocolo Facultativo de la Convención de los derechos de la niñez, relativo a venta, prostitución y pornografía, Ratificado por Colombia a través de la Ley 765 de 2002',
      subHeader: 'Norma Internacional',
      message: 'Los Estados se obligan a prohibir la venta de niños y su utilización en la prostitución y en la pornografía; establecer normas penales para su investigación y sanción1; hacer efectiva la jurisdicción del Estado en esos delitos e incluirlos en los tratados de extradición suscritos entre Estados; proteger a las víctimas en todas las fases del proceso penal, y difundir las leyes, medidas administrativas y políticas destinadas a prevenir esos delitos. Artículo 3: definiciones de los tipos penales. Artículos 4 y 5: Extraterritorialidad de los delitos de venta y explotación sexual en la prostitución y pornografía Artículo 8: 1. Proteger en todas las fases del proceso penal derechos e intereses de las víctimas: a) Adaptar los procedimientos a sus necesidades especiales; b) Informar a las víctimas; c) Considerar sus opiniones. d) Prestar la debida asistencia; e) Proteger debidamente la intimidad e identidad; f) Velar por su seguridad de víctimas, así como familias y testigos a su favor. g) Evitar las demoras innecesarias. 2. Que el hecho de haber dudas acerca de la edad real de la víctima no impida la iniciación de las investigaciones penales. 5. Proteger la seguridad de personas u organizaciones dedicadas a la prevención o la protección de las víctimas.',
      buttons: ['¡Entendido!']
    });

    await alert.present();
  }
  async traficoMenores() {
    const alert = await this.alertController.create({
      header: 'Convención Interamericana sobre Tráfico Internacional de Menores - 1994 ',
      subHeader: 'Norma Internacional',
      message: 'Se obliga a los Estados Parte proporcionar la protección, la prevención y la sanción del tráfico internacional de “menores” a través de mecanismo e instrumentos legales y administrativos, así como un sistema de cooperación jurídica entre los Estados Parte, definido por el artículo 1.',
      buttons: ['¡Entendido!']
    });

    await alert.present();
  }
  async estatutoRoma() {
    const alert = await this.alertController.create({
      header: 'Estatuto de Roma de la Corte Penal Internacional -CPI- 1998',
      subHeader: 'Norma Internacional',
      message: 'Dentro de los crímenes juzgados por la Corte Penal Internacional –CPI-, como son los crímenes contra la humanidad se encuentra los delitos de “violación, esclavitud sexual, prostitución forzada, embarazo forzado, esterilización forzada o cualquier otra forma de violencia sexual de gravedad comparable”.',
      buttons: ['¡Entendido!']
    });

    await alert.present();
  }
  async convNacUni() {
    const alert = await this.alertController.create({
      header: 'Convención de las Naciones Unidas contra la Delincuencia Organizada Transnacional – 15 de noviembre de 2000',
      subHeader: 'Norma Internacional',
      message: 'Tiene como objetivo la promoción de la cooperación internacional para la lucha contrala delincuencia organizada transnacional. Uno de los delitos por el cual se crea este instrumento es combatir la trata de mujeres y niños, niñas y adolescentes.',
      buttons: ['¡Entendido!']
    });

    await alert.present();
  }
  async protPrevSupreCast() {
    const alert = await this.alertController.create({
      header: 'Protocolo para la Prevención, Supresión y Castigo del Tráfico de Personas, Mujeres y Niños que complementa a la Convención de las Naciones Unidas sobre la Delincuencia Transnacional Organizada, PALERMO Ratificado el 25 de diciembre de 2003 por ley 800 DE 2003 ',
      subHeader: 'Norma Internacional',
      message: 'El Protocolo para Prevenir Reprimir y Sancionar la Trata de Personas especialmente de Mujeres y Niños a través de este instrumento los Estados que lo suscriben se obligan a: a) Prevenir y combatir la trata de personas, prestando especial atención a las mujeres y los niños; b) Proteger y ayudar a las víctimas de dicha trata, respetando plenamente sus derechos humanos; y c) Promover la cooperación entre los Estados Parte para lograr esos fines. Su ratificación obliga a los Estados a fortalecer su legislación nacional y apoyar internacionalmente la coordinación del orden público para combatir la trata de personas. Por “explotación sexual” se entenderá la obtención de beneficios económicos o de otro tipo mediante la participación de una persona en la prostitución, la servidumbre sexual u otros tipos de “servicios sexuales”, incluidos los actos pornográficos o la producción de material pornográfico.',
      buttons: ['¡Entendido!']
    });

    await alert.present();
  }
  async decProgAccionCong() {
    const alert = await this.alertController.create({
      header: 'Declaración y Programa de Acción, Primer Congreso Mundial Contra la Explotación Sexual Comercial de los Niños – Estocolmo, Suecia, 27al 31 de agosto de 1996',
      subHeader: 'Norma Internacional',
      message: 'El Primer Congreso Mundial sobre Explotación Sexual tiene en cuenta como instrumento internacional la Convención sobre los Derechos del Niño, en el cual se establecieron compromisos a nivel nacional, regional e internacional. También se tienen cuenta la prevención, la protección, la recuperación y reintegración, en donde se incluye un “enfoque no punitivo hacia las víctimas de la Explotación Sexual Comercial”.',
      buttons: ['¡Entendido!']
    });

    await alert.present();
  }
  async segCongYokohama() {
    const alert = await this.alertController.create({
      header: 'Compromiso Mundial de Yokohama, Segundo Congreso Mundial contra la Explotación Sexual Comercial de Niños, Japón - 17 al 20 diciembre de 2001',
      subHeader: 'Norma Internacional',
      message: 'El compromiso Mundial de Yokohama en su documento menciona los adelantos hasta el momento y posterior al Primer Congreso Mundial de algunos países, así como los adelantos en materia de normatividad internacional. Se reitera en el compromiso mundial y los retos a enfrentar.',
      buttons: ['¡Entendido!']
    });

    await alert.present();
  }
  async decRio() {
    const alert = await this.alertController.create({
      header: 'Declaración de Río de Janeiro y el llamamiento a la adopción de medidas para prevenir y detener la explotación sexual de niños y adolescentes – 25 al 28 de noviembre de 2008 ',
      subHeader: 'Norma Internacional',
      message: 'En el marco del Tercer Congreso Mundial contra la ESCNNA, se realizó un análisis de los avances hasta al momento, y las preocupaciones y retos a enfrentar. Un llamado a la acción, teniendo en cuenta los instrumentos internacionales y regionales, las formas de explotación sexual y su nuevos escenarios, políticas y planes de acción nacionales, monitoreo e iniciativas de responsabilidad social, entre otros.',
      buttons: ['¡Entendido!']
    });

    await alert.present();
  }

  async constitucion() {
    const alert = await this.alertController.create({
      header: 'Constitución Política de Colombia 1991 El Artículo 44 y 45',
      subHeader: 'Norma Nacional',
      message: 'Establece los derechos fundamentales de los niños y niñas, como también la protección de aquellas formas de violencia y vulneraciones entre las que se encuentran la “violencia física o moral, secuestro, venta, abuso sexual, explotación laboral o económica y trabajos riesgosos”, entre otros. Así mismo, los adolescentes “tienen derecho a la protección y a la formación integral” ',
      buttons: ['¡Entendido!']
    });

    await alert.present();
  }
  async ley679() {
    const alert = await this.alertController.create({
      header: 'Ley 679 de 2001 ',
      subHeader: 'Norma Nacional',
      message: 'Esta ley establece la promoción de sistemas de autorregulación (art. 6) con relación a las redes globales de información. Así mismo, una serie de prohibiciones, deberes y prevenir y contrarrestar la explotación, la pornografía y el turismo sexual en menores, en desarrollo del artículo 44 de la Constitución sanciones (art. 7, 8 y 10) específicas a proveedores o servidores, administradores y usuarios, respecto al alojamiento de vínculos o material de tipo pornográfico. Y deberes en cuento a la denuncia y la lucha contra estas prácticas. También contempla las medidas de sensibilización (art. 12), el desarrollo de un sistema de información sobre delitos sexuales contra “menores”, programas de sensibilización turística (art. 16), la vigilancia y control así como la capacitación al personal de la policía (art. 25, 26 y 28) y la investigación estadística (art. 36, modificado por el artículo 13 dela ley 1336).',
      buttons: ['¡Entendido!']
    });

    await alert.present();
  }
  async dec1524() {
    const alert = await this.alertController.create({
      header: 'Decreto 1524 de 2002',
      subHeader: 'Norma Nacional',
      message: 'Prevenir el acceso de menores de edad a pornografía en internet y evitar que estos medios sean utilizados con fines de explotación sexual u ofrecimiento de servicios comerciales que impliquen abuso sexual con menores de edad. En el decreto se define qué se entiende por pornografía infantil para la aplicación de la ley, los deberes que tienen los proveedores o servidores de internet en el país para impedir la divulgación de mensajes o información pornográficos, así como las sanciones para aquellos que por omisión incurran en faltas contra la ley.',
      buttons: ['¡Entendido!']
    });

    await alert.present();
  }
  async ley1098() {
    const alert = await this.alertController.create({
      header: 'Ley 1098 de 2006',
      subHeader: 'Norma Nacional',
      message: 'Establece las normas para la protección integral de los niños, niñas y adolescentes, y obliga a la garantía y restablecimiento en el ejercicio de sus derechos y libertades. De este modo, contempla principios y normas como la protección integral, el interés superior de los niños, niñas y adolescentes, la prevalencia de sus derechos, la corresponsabilidad y la exigibilidad de sus derechos. Art. 192. Derechos Especiales De Los Niños, Las Niñas Y Los Adolescentes Víctimas De Delitos. En los procesos por delitos en los cuales los niños, las niñas o los adolescentes sean víctimas el funcionario judicial tendrá en cuenta los principios del interés superior del niño, prevalencia de sus derechos, protección integral y los derechos consagrados en los Convenios Internacionales ratificados por Colombia, en la Constitución Política y en esta ley. Art. 193 En todas las diligencias en que intervengan NNA víctimas de delitos se les tenga en cuenta su opinión, se les respete su dignidad, intimidad y demás derechos. Igualmente velará porque no se les estigmatice, ni se les generen nuevos daños con el desarrollo de proceso judicial de los responsables…Ordenará la toma de medidas especiales para garantizar la seguridad de víctimas y/o testigos de delitos y de su familia, cuando a causa de la investigación del delito se hagan necesarias. Art. 196. Los niños y niñas víctimas, tendrán derecho a ser asistidos durante el juicio y el incidente de reparación integral por un abogado (a) calificado que represente sus intereses aún sin el aval de sus padres y designado por el Defensor del Pueblo. Art. 199 Cuando se trate de los delitos… contra la libertad, integridad y formación sexuales,…, contra NNA, procede: Medida de aseguramiento detención en establecimiento de reclusión. No aplicables medidas no privativas de la libertad. No se otorgará el beneficio de detención en el lugar de residencia. No procederá principio de oportunidad. No procederán las rebajas de pena con base en los “preacuerdos y negociaciones entre la fiscalía y el imputado o acusado”. Ningún otro beneficio o subrogado judicial o administrativo, salvo los beneficios por colaboración consagrados en el Código de Procedimiento Penal, siempre que esta sea efectiva.',
      buttons: ['¡Entendido!']
    });

    await alert.present();
  }
  async ley1146() {
    const alert = await this.alertController.create({
      header: 'Ley 1146 de 2007',
      subHeader: 'Norma Nacional',
      message: 'El sector educativo y la prevención del abuso sexual contra niños, niñas y adolescentes artículos 11 al 13. Modelo de formación para la ciudadanía. Prevención de la violencia sexual y atención integral de los niños, niñas y adolescentes abusados sexualmente. La Superintendencia Nacional de Salud, podrá imponer, en caso de violación de la Ley 1146 de 2007, a las, EPS, IPS, y Entidades Promotoras de Salud de Salud del Régimen Subsidiado, EPS-S, multas de 1 a 2000 smlmv, nieguen la atención de manera inmediata como una urgencia médica del niño, niña y adolescente víctima de abuso sexual o que durante la atención médica de urgencia no realicen una adecuada evaluación física y psicológica del niño, niña o adolescente víctima, teniendo cuidado de preservar la integridad de las evidencias. b) que incumplan el precepto de recoger de manera oportuna y adecuada las evidencias, siguiendo las normas de la cadena de custodia, c)… que nieguen antiretrovirales en caso de violación y/o riesgo de VIH/Sida, o a la realización de exámenes y tratamientos. d) … que se abstengan de dar aviso inmediato a la policía judicial y al ICBF.',
      buttons: ['¡Entendido!']
    });

    await alert.present();
  }
  async ley1336() {
    const alert = await this.alertController.create({
      header: 'Ley 1336 de 2009',
      subHeader: 'Norma Nacional',
      message: 'Contiene un extenso articulado (28 artículos) que asigna funciones y roles específicos a varias entidades del nivel nacional de Gobierno con el objeto de prevenir la ocurrencia del delito de la ESCNNA. En su art. 6 sobre las estrategias de sensibilización, se específica las acciones a realizaren materia de sensibilización e información por parte del Ministerio de Comercio, Industria y Turismo, en cuanto al “fenómeno del turismo sexual con niños, niñas y adolescentes”. El art.36 con respecto a la investigación estadística obliga a procesar y consolidar “información mediante un formato único que deben diligenciar las organizaciones gubernamentales y no gubernamentales, y realizar al menos cada dos años investigaciones que permitan recaudar información estadística” respecto al fenómeno de Explotación Sexual Comercial en Niños, Niñas y Adolescentes. Modifica asimismo el Código Penal (Ley 599 de 2000); se adiciona el artículo 219(derogado anteriormente por la Ley 747 de 2002) sobre turismo sexual, y modifica el artículo 218 sobre pornografía con personas menores de 18 años.',
      buttons: ['¡Entendido!']
    });

    await alert.present();
  }
  async ley1329() {
    const alert = await this.alertController.create({
      header: 'Ley 1329 de 2009',
      subHeader: 'Norma Nacional',
      message: 'Según esta ley se adicionan nuevos artículos modificando el Código Penal. De este modo, se incorporan respecto a la penalización del proxenetismo con “menor de edad” el art. 213-A, respecto a la demanda de Explotación Sexual Comercial de persona menor de 18 años de edad el art. 217-A, y se disposiciones para contrarrestarla explotación sexual comercial de niños, niñas y adolescentes modifica el artículo 219-A respecto a la utilización o facilitación de medios de comunicación para ofrecer actividades sexuales con personas menores de 18 años',
      buttons: ['¡Entendido!']
    });

    await alert.present();
  }
  async ley1620() {
    const alert = await this.alertController.create({
      header: 'Ley 1620 de 2013',
      subHeader: 'Norma Nacional',
      message: 'Activación de la ruta de Atención Integral para la Convivencia Escolar que permita fijar la conformación y funcionamiento del sistema de información unificado y establecer las pautas mínimas sobre cómo aplicar la ruta y los protocolos para prevenir y mitigar las situaciones que afecten la convivencia escolar y ejercicio de los derechos sexuales y reproductivos.',
      buttons: ['¡Entendido!']
    });

    await alert.present();
  }

  async prostitucion() {
    const alert = await this.alertController.create({
      header: 'El término o la expresión correcta es:',
      subHeader: 'Explotación de NNA en prostitución',
      message: 'El contenido y alcance de esta expresión ha sido entendida como una forma de trasladar la culpa al NNA de su explotación o normalizar la misma por la presencia de un intercambio. De igual forma la expresión genera la sensación de una práctica normalizada en entornos en donde la prostitución es aceptada.',
      buttons: ['¡Entendido!']
    });

    await alert.present();
  }

  async pornografia() {
    const alert = await this.alertController.create({
      header: 'El término o la expresión correcta es:',
      subHeader: 'Utilización / Explotación de NNA en pornografía',
      message: 'La pornografía infantil lleva a normalizar la explotación de los NNA en la producción, distribución o cualquier acto que involucre este tipo de material al no considerar la pornografía en sí misma el objeto del reproche.',
      buttons: ['¡Entendido!']
    });

    await alert.present();
  }

  async turismo() {
    const alert = await this.alertController.create({
      header: 'El término o la expresión correcta es:',
      subHeader: 'Explotación sexual de NNA en el contexto de viajes y turismo',
      message: 'A pesar de que el tipo penal está configurado de esta forma en la legislación nacional, el término puede generar el riesgo de normalización. La palabra turismo reduce la operación de explotación a los viajes que se realizan con fines de recreación y excluye otros viajes como los asociados a negocios.',
      buttons: ['¡Entendido!']
    });

    await alert.present();
  }

  async trabajo() {
    const alert = await this.alertController.create({
      header: 'Los términos y/o expresiones correctas son:',
      subHeader: '1. Explotación sexual comercial de niños, niñas y adolescentes. 2. Niño, niña y adolescente explotado sexualmente.',
      message: 'El niño, niña o adolescente explotado sexualmente no se puede considerar trabajador toda vez que precisamente no es un trabajo en sí mismo sino una situación de vulneración de derechos.',
      buttons: ['¡Entendido!']
    });

    await alert.present();
  }

  async cliente() {
    const alert = await this.alertController.create({
      header: 'El término o la expresión correcta es:',
      subHeader: 'Cliente – explotador',
      message: 'La sola expresión cliente tiende a normalizar el intercambio, toda vez que se puede llegar a entender que se trata de una relación normal de transacción.',
      buttons: ['¡Entendido!']
    });

    await alert.present();
  }

  async menor() {
    const alert = await this.alertController.create({
      header: 'El término o la expresión correcta es:',
      subHeader: 'Menor de 18 años Niños, niñas y adolescentes',
      message: 'La expresión menor es considerada una forma de señalamiento de los NNA en una condición de inferioridad e incapacidad y por tanto no como sujeto de derechos.',
      buttons: ['¡Entendido!']
    });

    await alert.present();
  }

  toSatmedThemes(){
    this.router.navigateByUrl("/aprende-satmed-section");
  }

  ngOnInit() {
  }

}
