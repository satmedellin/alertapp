import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-emergencia-prea',
  templateUrl: './emergencia-prea.page.html',
  styleUrls: ['./emergencia-prea.page.scss'],
})
export class EmergenciaPreaPage implements OnInit {

  constructor(private router: Router) { }

  toSatmedHelp(){
    this.router.navigateByUrl("/emergencia-section");
  }

  ngOnInit() {
  }

}
