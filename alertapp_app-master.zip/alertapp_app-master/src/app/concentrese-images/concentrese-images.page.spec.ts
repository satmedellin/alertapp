import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConcentreseImagesPage } from './concentrese-images.page';

describe('ConcentreseImagesPage', () => {
  let component: ConcentreseImagesPage;
  let fixture: ComponentFixture<ConcentreseImagesPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConcentreseImagesPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConcentreseImagesPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
