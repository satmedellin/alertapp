import { Component, OnInit } from '@angular/core';
import { AlertController } from '@ionic/angular';

@Component({
  selector: 'app-concentrese-images',
  templateUrl: './concentrese-images.page.html',
  styleUrls: ['./concentrese-images.page.scss'],
})
export class ConcentreseImagesPage implements OnInit {

  constructor(public alertController: AlertController) { }
  async presentAlert() {
    const alert = await this.alertController.create({
      header: 'Instrucciones',
      subHeader: 'Este es un juego en el cual debes recordar las imágenes que descubres',
      message: 'Primero Descubre las imágenes hasta hacer coincidir dos iguales. </br> </br>Segundo, responde las preguntas y continúa descubriendo imágenes.',
      buttons: ['¡Listo!']
    });

    await alert.present();
  }

  ngOnInit() {
  }

}
