import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AliadosSatmedPage } from './aliados-satmed.page';

describe('AliadosSatmedPage', () => {
  let component: AliadosSatmedPage;
  let fixture: ComponentFixture<AliadosSatmedPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AliadosSatmedPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AliadosSatmedPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
