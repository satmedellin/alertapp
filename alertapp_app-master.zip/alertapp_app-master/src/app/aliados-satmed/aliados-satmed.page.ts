import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aliados-satmed',
  templateUrl: './aliados-satmed.page.html',
  styleUrls: ['./aliados-satmed.page.scss'],
})
export class AliadosSatmedPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
