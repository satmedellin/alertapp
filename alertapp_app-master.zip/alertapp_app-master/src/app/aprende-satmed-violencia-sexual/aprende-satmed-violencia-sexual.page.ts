import { Component, OnInit } from '@angular/core';
import { AlertController } from '@ionic/angular';
import { Router } from '@angular/router';

@Component({
  selector: 'app-aprende-satmed-violencia-sexual',
  templateUrl: './aprende-satmed-violencia-sexual.page.html',
  styleUrls: ['./aprende-satmed-violencia-sexual.page.scss'],
})
export class AprendeSatmedViolenciaSexualPage implements OnInit {

  constructor(public alertController: AlertController, private router: Router) { }

  async res3318() {
    const alert = await this.alertController.create({
      header: 'Resolución 3318 del 14 de diciembre 1974',
      subHeader: 'Norma Nacional',
      message: 'Instrumento para la protección de niños y niñas en los conflictos armados. Esta Declaración señala que los Estados deben hacer todos los esfuerzos necesarios para evitar los impactos de la guerra en mujeres, niños y niñas.',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }

  async ley51() {
    const alert = await this.alertController.create({
      header: 'Ley 51 de 1981',
      subHeader: 'Norma Nacional',
      message: 'Entrada en rigor de la Convención de la CEDAW para eliminar la discriminación contra la mujer, incluye niñas y adolescentes, en la vida política y pública del país.',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }

  async ley248() {
    const alert = await this.alertController.create({
      header: 'Ley 248 de 1995',
      subHeader: 'Norma Nacional',
      message: 'Garantizar a las mujeres incluye niñas y adolescentes, el derecho a una vida libre de violencia tanto en el ámbito público como privado y el principio de la debida diligencia..',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }

  async ley765() {
    const alert = await this.alertController.create({
      header: 'Ley 765 de 2002',
      subHeader: 'Norma Nacional',
      message: 'Herramienta jurídica destinada a definir y prohibir la participación de niños y niñas en prostitución y pornografía.',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }

  async ley599() {
    const alert = await this.alertController.create({
      header: 'Ley 599 de 2000',
      subHeader: 'Norma Nacional',
      message: 'define en su Título IV los delitos contra la Libertad, Integridad Formación sexuales, artículos 205 al 219B, a todas las conductas que resultan vulneratorias de los bienes jurídicamente tutelados, descritos en dicho titulo.',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }

  async ley679() {
    const alert = await this.alertController.create({
      header: 'Ley 679 de 2001',
      subHeader: 'Norma Nacional',
      message: 'Por medio de la cual se expide un estatuto para prevenir y contrarrestar la explotación, la pornografía y el turismo sexual con menores, en desarrollo del artículo 44 de la Constitución política de Colombia.',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }

  async ley1146() {
    const alert = await this.alertController.create({
      header: 'Ley 1146 de 2007',
      subHeader: 'Norma Nacional',
      message: 'Tiene por objeto la prevención de la violencia sexual y la atención integral de los niños, las niñas y adolescentes víctimas de abuso sexual.',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }

  async sentC355() {
    const alert = await this.alertController.create({
      header: 'Sentencia C-355 de 2006',
      subHeader: 'Norma Nacional',
      message: 'Despenaliza el aborto y establece el sustento jurídico para la atención de la Interrupción Voluntaria del Embarazo IVE.',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }

  async res1820() {
    const alert = await this.alertController.create({
      header: 'Resolución 1820 de 2008',
      subHeader: 'Norma Nacional',
      message: 'Reconoce que la violación y otras formas de violencia sexual pueden constituir un crimen de guerra, un crimen de lesa humanidad o un acto constitutivo con respecto al genocidio. Destaca la necesidad de que los crímenes de violencia sexual queden excluidos de las disposiciones de amnistía en el contexto de los procesos de solución de conflictos. Igualmente, hace un llamado a los Estados miembro para que cumplan con enjuiciar a los responsables de tales actos y se garanticé a niñas, adolescentes y mujeres víctimas protección y acceso a la justicia.',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }

  async ley1236() {
    const alert = await this.alertController.create({
      header: 'Ley 1236 de 2008',
      subHeader: 'Norma Nacional',
      message: 'Por medio del cual se modifican algunos artículos del Código Penal relativos a delitos de abuso sexual (incremento de penas).',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }

  async ley1257() {
    const alert = await this.alertController.create({
      header: 'Ley 1257 de 2008',
      subHeader: 'Norma Nacional',
      message: 'Por la cual se dictan normas de sensibilización, prevención y sanción de Por la cual se dictan normas de sensibilización, prevención y sanción.',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }

  async ley1329() {
    const alert = await this.alertController.create({
      header: 'Ley 1329 de 2009',
      subHeader: 'Norma Nacional',
      message: 'Por medio de la cual se modifica el título IV de la ley 599 del 2000 y se dictan otras disposiciones para contrarrestar la explotación sexual comercial.',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }

  async dec2734() {
    const alert = await this.alertController.create({
      header: 'Decreto 2734 de 2012',
      subHeader: 'Norma Nacional',
      message: 'Por el cual se reglamentan las medidas de atención a las mujeres víctimas de la violencia.',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }

  async res459() {
    const alert = await this.alertController.create({
      header: 'Resolución 459 de 2012',
      subHeader: 'Norma Nacional',
      message: 'Por la cual se adopta el Protocolo y Modelo de Atención Integral en Salud para Víctimas de Violencia Sexual.',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }

  async ley1652() {
    const alert = await this.alertController.create({
      header: 'Ley 1652 de 2013',
      subHeader: 'Norma Nacional',
      message: 'Por medio de la cual se dictan otras disposiciones acerca de la entrevista y el testimonio en procesos penales de niños, niñas y adolescentes víctimas de delitos contra la libertad, integridad y formación sexuales.',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }

  async ley1719() {
    const alert = await this.alertController.create({
      header: 'Ley 1719 de 2014',
      subHeader: 'Norma Nacional',
      message: 'Por la cual se adoptan medidas para garantizar el acceso a la justicia de las víctimas de violencia sexual, en especial la violencia sexual con ocasión del conflicto armado, y se dictan otras disposiciones. Estas medidas buscan atender de manera prioritaria las necesidades de las mujeres, niñas, niños y adolescentes víctimas.',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }


  toSatmedThemes(){
    this.router.navigateByUrl("/aprende-satmed-section");
  }

  ngOnInit() {
  }

}
