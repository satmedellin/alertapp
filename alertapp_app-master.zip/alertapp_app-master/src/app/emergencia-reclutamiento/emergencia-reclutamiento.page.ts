import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-emergencia-reclutamiento',
  templateUrl: './emergencia-reclutamiento.page.html',
  styleUrls: ['./emergencia-reclutamiento.page.scss'],
})
export class EmergenciaReclutamientoPage implements OnInit {

  constructor(private router: Router) { }

  toSatmedHelp(){
    this.router.navigateByUrl("/emergencia-section");
  }

  ngOnInit() {
  }

}
