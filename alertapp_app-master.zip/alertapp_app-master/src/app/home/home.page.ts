import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { StorageService, Usuario } from '../services/storage.service';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
  usuarios: Usuario[] = [];
  numUsuario: boolean;
  gameLink: string;

  constructor(private storageService: StorageService, private router: Router) {
    this.loadItems();
    if (!this.usuarios) {
      this.numUsuario = false;
      this.gameLink = '/cuenta';
    } else {
      this.numUsuario = true;
      this.gameLink = '/juego-alertar';
    }
  }

  // READ
  loadItems() {
    this.storageService.getItems().then(usuarios => {
      this.usuarios = usuarios;
      if (!this.usuarios) {
          this.numUsuario = false;
          this.gameLink = '/cuenta';
      } else {
        this.numUsuario = true;
        this.gameLink = '/juego-alertar';
      }
    });
  }

  toAprendeSection() {
    this.router.navigateByUrl('/aprende-satmed-section');
  }

  toConcentreseGame() {
    this.router.navigateByUrl('/concentrese-images');
  }

  toInformateSection() {
    this.router.navigateByUrl('/informate-section');
  }

  toCoronavirus() {
    this.router.navigateByUrl('/coronavirus-covid19');
  }

  toEmergenciaSection() {
    this.router.navigateByUrl('/emergencia-section');
  }

  toAcercaDe() {
    this.router.navigateByUrl('/acercade-satmed');
  }

  toTerminosCondiciones() {
    this.router.navigateByUrl('/terminos-condiciones');
  }

}
