import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-emergencia-section',
  templateUrl: './emergencia-section.page.html',
  styleUrls: ['./emergencia-section.page.scss'],
})
export class EmergenciaSectionPage implements OnInit {

  constructor(private router: Router) { }

  toEmergenciaViolenciaSexual(){
    this.router.navigateByUrl("/emergencia-violencia-sexual");
  }

  toEmergenciaEscnna(){
    this.router.navigateByUrl("/emergencia-escnna");
  }

  toEmergenciaReclutamiento(){
    this.router.navigateByUrl("/emergencia-reclutamiento");
  }

  toEmergenciaTrabajo(){
    this.router.navigateByUrl("/emergencia-trabajo-infantil");
  }

  toEmergenciaPrea(){
    this.router.navigateByUrl("/emergencia-prea");
  }

  ngOnInit() {
  }

}
