import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NoticiaOpenThreePage } from './noticia-open-three.page';

describe('NoticiaOpenThreePage', () => {
  let component: NoticiaOpenThreePage;
  let fixture: ComponentFixture<NoticiaOpenThreePage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NoticiaOpenThreePage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NoticiaOpenThreePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
