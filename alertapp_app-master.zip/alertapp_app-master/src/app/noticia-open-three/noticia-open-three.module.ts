import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';

import { IonicModule } from '@ionic/angular';

import { NoticiaOpenThreePage } from './noticia-open-three.page';

const routes: Routes = [
  {
    path: '',
    component: NoticiaOpenThreePage
  }
];

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RouterModule.forChild(routes)
  ],
  declarations: [NoticiaOpenThreePage]
})
export class NoticiaOpenThreePageModule {}
