import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-noticia-open-three',
  templateUrl: './noticia-open-three.page.html',
  styleUrls: ['./noticia-open-three.page.scss'],
})
export class NoticiaOpenThreePage implements OnInit {

  constructor(private router: Router) { }

  toSatmedNews(){
    this.router.navigateByUrl("/informate-section");
  }

  ngOnInit() {
  }

}
