import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-noticia-open',
  templateUrl: './noticia-open.page.html',
  styleUrls: ['./noticia-open.page.scss'],
})
export class NoticiaOpenPage implements OnInit {

  constructor(private router: Router) { }

  toSatmedNews(){
    this.router.navigateByUrl("/informate-section");
  }

  ngOnInit() {
  }

}
