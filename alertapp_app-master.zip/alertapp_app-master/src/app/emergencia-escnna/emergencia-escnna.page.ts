import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-emergencia-escnna',
  templateUrl: './emergencia-escnna.page.html',
  styleUrls: ['./emergencia-escnna.page.scss'],
})
export class EmergenciaEscnnaPage implements OnInit {

  constructor(private router: Router) { }

  toSatmedHelp(){
    this.router.navigateByUrl("/emergencia-section");
  }

  ngOnInit() {
  }

}
