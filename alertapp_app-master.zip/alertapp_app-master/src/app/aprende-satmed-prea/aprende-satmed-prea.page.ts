import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController } from '@ionic/angular';

@Component({
  selector: 'app-aprende-satmed-prea',
  templateUrl: './aprende-satmed-prea.page.html',
  styleUrls: ['./aprende-satmed-prea.page.scss'],
})
export class AprendeSatmedPreaPage implements OnInit {

  constructor(public alertController: AlertController, private router: Router) { }

  async constitucion() {
    const alert = await this.alertController.create({
      header: 'Constitución Política de 1991',
      subHeader: 'Norma Nacional',
      message: 'Reconoce los derechos de las niñas, niños y adolescentes y plantea los imperativos de la acción estatal en torno al interés superior del niño y su protección integral.',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }
  async ley115() {
    const alert = await this.alertController.create({
      header: 'Ley 115 de 1994 ',
      subHeader: 'Norma Nacional',
      message: 'Promueve la educación sexual de acuerdo con las condiciones de edad, características y necesidades de los-as estudiantes, a partir de la construcción de proyectos pedagógicos. Surge de ella el Programa de Educación para la Sexualidad y Construcción de Ciudadanía, PESCC (2007).',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }
  async ley1146() {
    const alert = await this.alertController.create({
      header: 'Ley 1146 de 2007',
      subHeader: 'Norma Nacional',
      message: 'Por medio de la cual se expiden normas para la prevención de la violencia sexual y atención integral de los niños, niñas y adolescentes abusados sexualmente.',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }
  async ley1098() {
    const alert = await this.alertController.create({
      header: 'Ley 1098 de 2006',
      subHeader: 'Norma Nacional',
      message: 'Por la cual se expide el código de la infancia y la adolescencia.',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }
  async dec3705() {
    const alert = await this.alertController.create({
      header: 'Decreto 3705 de 2007',
      subHeader: 'Norma Nacional',
      message: 'Por el cual se declara el día nacional de la prevención del embarazo en adolescentes el 26 de septiembre de cada año basado en la propuesta del Centro Latinoamericano Salud y Mujer (CELSAM), con el propósito de articular acciones entre instancias públicas y privadas para informar y sensibilizar a la sociedad acerca de la importancia de la prevención de embarazos en adolescentes, y velar por el cumplimiento y respeto de los derechos sexuales y reproductivos de esta población.',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }
  async dec2968() {
    const alert = await this.alertController.create({
      header: 'Decreto 2968 de 2010',
      subHeader: 'Norma Nacional',
      message: 'Crea la Comisión Nacional Intersectorial para la Promoción y Garantía de los Derechos Sexuales y Reproductivos.',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }
  async ley1620() {
    const alert = await this.alertController.create({
      header: 'Ley 1620 de 2013 ',
      subHeader: 'Norma Nacional',
      message: 'Crea el Sistema Nacional de Convivencia Escolar que frente a la prevención del embarazo en la adolescencia, contempla la promoción y fortalecimiento de la formación ciudadana y el ejercicio de los derechos humanos, sexuales y reproductivos de los estudiantes.',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }
  async res1841() {
    const alert = await this.alertController.create({
      header: 'Resolución 1841 de 2013',
      subHeader: 'Norma Nacional',
      message: 'Por la cual se adopta el Plan Decenal de Salud Pública 2012 – 2021, el cual Establece como una de sus dimensiones prioritarias la Sexualidad, Derechos Sexuales y Reproductivos, buscan concretar la preocupación y el compromiso por la salud integral, la salud sexual y la salud reproductiva como derechos fundamentales de las personas y su entendimiento como medio para que el bienestar físico, mental y social sea posible.',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }
  async polNaciSex() {
    const alert = await this.alertController.create({
      header: 'Política Nacional de Sexualidad, Derechos Sexuales y Derechos Reproductivos 2014-2021',
      subHeader: 'Norma Nacional',
      message: 'Se fundamenta en los enfoques de: derechos, aplicados a lo sexual y a lo reproductivo desde un concepto amplio de sexualidad; sumado al enfoque de género, diferencial y de curso de vida, para proponer las acciones de Estado que en esta materia se reconocen como promoción, prevención, diagnóstico, tratamiento, rehabilitación y paliación, según se contempla en la Ley Estatutaria.',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }
  async ley1753() {
    const alert = await this.alertController.create({
      header: 'Ley 1753 de 2015 ',
      subHeader: 'Norma Nacional',
      message: 'Por la cual se expide el Plan Nacional de Desarrollo 2014 - 2018 “Todos por un Nuevo País”, en su artículo 65, regula la política integral en salud y determina la adaptación de la misma a los ámbitos territoriales. En el artículo 84 contempla la prevención del embarazo en la adolescencia como una prioridad en materia de niñez y adolescencia y responsabiliza al ICBF y el Ministerio de Salud y Protección Social de su coordinación y asistencia técnica en el marco de la Comisión Nacional Intersectorial para la Promoción y Garantía de los Derechos Sexuales y Reproductivos.',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }
  async ley1751() {
    const alert = await this.alertController.create({
      header: 'Ley 1751 de 2015 ',
      subHeader: 'Norma Nacional',
      message: 'Ley Estatutaria de Salud. Tiene por objetivo “garantizar el derecho a la salud, regularlo y establecer sus mecanismos de protección”, hace un giro esencial cuando situó el derecho a la salud en el ámbito del Sistema de Salud y no del Sistema de Seguridad Social en Salud y reconoció además su carácter de derecho social fundamental.',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }
  async estAtencion() {
    const alert = await this.alertController.create({
      header: 'Estrategia de atención integral para niñas, niños y adolescentes con énfasis en prevención del embarazo en la infancia y adolescencia 2015-2025',
      subHeader: 'Norma Nacional',
      message: 'Estrategia nacional propuesta por la Comisión Nacional Intersectorial para la Promoción y Garantía de los Derechos Sexuales y Reproductivos, de la cual hace parte el Ministerio de Salud y Protección Social, da continuidad al CONPES 147 de 2012; se define como el “conjunto de decisiones políticas y acciones planificadas de carácter nacional y territorial, dirigidas hacia la promoción y garantía del desarrollo integral de niñas, niños y adolescentes, con énfasis en la prevención del embarazo y la reducción del subsiguiente, en el marco de la promoción de los derechos sexuales y los derechos reproductivos- DSDR-“.',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }
  async res0429() {
    const alert = await this.alertController.create({
      header: 'Resolución 0429 de 2016',
      subHeader: 'Norma Nacional',
      message: 'Por medio de la cual se adopta la Política de Atención Integral en Salud (PAIS).',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }
  async res3202() {
    const alert = await this.alertController.create({
      header: 'Resolución 3202 de 2016',
      subHeader: 'Norma Nacional',
      message: 'Por la cual se adopta el Manual Metodológico para la elaboración e implementación de las Rutas Integrales de Atención en Salud — RIAS, se adopta un grupo de Rutas Integrales de Atención en Salud desarrolladas por el Ministerio de Salud y Protección Social dentro de la Política de Atención Integral en Salud — PAIS y se dictan otras disposiciones.',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }
  async res3280() {
    const alert = await this.alertController.create({
      header: 'Resolución 3280 de 2018',
      subHeader: 'Norma Nacional',
      message: 'Por medio de la cual se adoptan los lineamientos técnicos y operativos de la Ruta Integral de Atención para la Promoción y Mantenimiento de la Salud y la Ruta Integral de Atención en Salud para la Población Materno Perinatal y se establecen las directrices para su operación.',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }
  async acuerdo003() {
    const alert = await this.alertController.create({
      header: 'Acuerdo 003 de 2016 ',
      subHeader: 'Norma Nacional',
      message: 'Por el cual se adopta el plan de desarrollo municipal 2016 -2019 “Medellín cuenta con vos”.',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }
  async planTerr() {
    const alert = await this.alertController.create({
      header: 'Plan Territorial de Salud 2016-2019 “Medellín para vivir más y mejor”',
      subHeader: 'Norma Nacional',
      message: 'En las estrategias del plan se prioriza y contempla el Proyecto: Abordaje integral socio sanitario para la prevención del embarazo adolescente y la promoción de los derechos sexuales y reproductivos.',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }
  async acuerdo84() {
    const alert = await this.alertController.create({
      header: 'Acuerdo 84 de 2006',
      subHeader: 'Norma Nacional',
      message: 'Por el cual se adopta una política pública de Protección y Atención integral a la infancia y la adolescencia y se crea el Consejo de Política de Infancia y Adolescencia en la ciudad de Medellín. El artículo 2 hace énfasis en la promoción de los derechos sexuales y reproductivos, la paternidad y maternidad responsable, la salud sexual y reproductiva.',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }
  async acuerdo54() {
    const alert = await this.alertController.create({
      header: 'Acuerdo 54 de 2011',
      subHeader: 'Norma Nacional',
      message: 'Política pública para la promoción, prevención, atención, protección, garantía y restablecimiento de los derechos para la familia en el municipio de Medellín.',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }
  async acuerdo20() {
    const alert = await this.alertController.create({
      header: 'Acuerdo 20 de 2011',
      subHeader: 'Norma Nacional',
      message: 'Por medio del cual se modifica el Acuerdo 09 de 2006 y se hacen ajustes a la Política Pública para la Prevención y Atención de las violencias sexuales que afectan a la ciudadanía, principalmente a mujeres, niñas, niños y adolescentes en el Municipio de Medellín.',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }
  async acuerdo019() {
    const alert = await this.alertController.create({
      header: 'Acuerdo 019 de 2014',
      subHeader: 'Norma Nacional',
      message: 'Por el cual se actualiza y adopta la Política pública de juventud de Medellín. En su artículo octavo contempla la formulación del Plan Estratégico de Juventud 2015-2027',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }
  async acuerdo23() {
    const alert = await this.alertController.create({
      header: 'Acuerdo 23 de 2011',
      subHeader: 'Norma Nacional',
      message: 'Por medio del cual se crea en la ciudad de Medellín la política pública de prevención del embarazo infantil y adolescente.',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }
  async planSexualidad() {
    const alert = await this.alertController.create({
      header: 'Plan de sexualidad, derechos sexuales y derechos reproductivos para Medellín 2018-2023',
      subHeader: 'Norma Nacional',
      message: 'Tiene como objetivo general promover condiciones de vida y procesos de gestión que favorezcan el ejercicio de los derechos sexuales y los derechos reproductivos de tal forma que se viabilice la vivencia de una sexualidad óptima, logrando el más alto nivel posible de salud sexual y salud reproductiva.',
      buttons: ['¡Entendido!']
    });
    await alert.present();
  }

  toSatmedThemes(){
    this.router.navigateByUrl("/aprende-satmed-section");
  }

  ngOnInit() {
  }

}
