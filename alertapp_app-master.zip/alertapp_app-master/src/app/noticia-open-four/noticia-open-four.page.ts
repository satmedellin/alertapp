import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-noticia-open-four',
  templateUrl: './noticia-open-four.page.html',
  styleUrls: ['./noticia-open-four.page.scss'],
})
export class NoticiaOpenFourPage implements OnInit {

  constructor(private router: Router) { }

  toSatmedNews(){
    this.router.navigateByUrl("/informate-section");
  }

  ngOnInit() {
  }

}
