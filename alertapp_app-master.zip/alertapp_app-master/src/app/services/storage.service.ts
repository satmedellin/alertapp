import { Injectable } from '@angular/core';
import { Storage } from '@ionic/storage';

export interface Usuario {
  id: number;
  nombre: string;
  edad: number;
  genero: string;
}

export interface Puntaje {
  puntuacion: number;
  tema: string;
  riesgo: string;
  orientacion: any[];
}

export interface Pregunta {
  randomPreg: string;
  resCorrecta: string;
  resRiesgo: string;
  orientacion: string;
  puntaje: number;
}

const ITEMS_KEY = 'my-items';

@Injectable({
  providedIn: 'root'
})
export class StorageService {

  constructor(private storage: Storage) { }

  // CREATE
  addItem(usuario: Usuario): Promise<any> {
    return this.storage.get(ITEMS_KEY).then((usuarios: Usuario[]) => {
      if (usuarios) {
        usuarios.push(usuario);
        return this.storage.set(ITEMS_KEY, usuarios);
      } else {
        return this.storage.set(ITEMS_KEY, [usuario]);
      }
    });
  }

  // READ
  getItems(): Promise<Usuario[]> {
    return this.storage.get(ITEMS_KEY);
  }

  // UPDATE
  updateItem(usuario: Usuario): Promise<any> {
    return this.storage.get(ITEMS_KEY).then((usuarios: Usuario[]) => {
      if (!usuarios || usuarios.length === 0) {
        return null;
      }

      const newUsuario: Usuario[] = [];

      for (const i of usuarios) {
        if (i.id === usuario.id) {
          newUsuario.push(usuario);
        } else {
          newUsuario.push(i);
        }
      }

      return this.storage.set(ITEMS_KEY, newUsuario);
    });
  }

}
