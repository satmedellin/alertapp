import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-noticia-open-one',
  templateUrl: './noticia-open-one.page.html',
  styleUrls: ['./noticia-open-one.page.scss'],
})
export class NoticiaOpenOnePage implements OnInit {

  constructor(private router: Router) { }

  toSatmedNews(){
    this.router.navigateByUrl("/informate-section");
  }

  ngOnInit() {
  }

}
