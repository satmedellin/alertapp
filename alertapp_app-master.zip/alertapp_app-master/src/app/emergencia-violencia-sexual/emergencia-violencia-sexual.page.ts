import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-emergencia-violencia-sexual',
  templateUrl: './emergencia-violencia-sexual.page.html',
  styleUrls: ['./emergencia-violencia-sexual.page.scss'],
})
export class EmergenciaViolenciaSexualPage implements OnInit {

  constructor(private router: Router) { }

  toSatmedHelp(){
    this.router.navigateByUrl("/emergencia-section");
  }

  ngOnInit() {
  }

}
