import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmergenciaViolenciaSexualPage } from './emergencia-violencia-sexual.page';

describe('EmergenciaViolenciaSexualPage', () => {
  let component: EmergenciaViolenciaSexualPage;
  let fixture: ComponentFixture<EmergenciaViolenciaSexualPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmergenciaViolenciaSexualPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmergenciaViolenciaSexualPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
